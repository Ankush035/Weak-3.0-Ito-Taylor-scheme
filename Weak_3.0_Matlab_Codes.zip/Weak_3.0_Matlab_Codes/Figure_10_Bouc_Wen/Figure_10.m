%  Fig 10: Ensemble mean displacement response of the 5-DOF base isolated
% 
%            5 dof Bouc-Wen degrading oscillator
% 
%   Higher order scheme (Weak Taylor 3.0 scheme) by Ito-Taylor eYpansion 
%  Comparison with Milstein scheme
% 
% Author: Tapas Tripura, Ankush Gogoi, Budhaditya Hazra
% Indian Institute of Technology Guwahati, Assam, India
% 
% ***********************************************************************
% 
clc;
clear;
close all;

% System parameters
mb=20; m1=20; m2=20; m3=20; m4=20;  % Mass
cb=10; c1=10; c2=10; c3=10; c4=10;  % Damping
kb=8000; k1=8000; k2=8000; k3=8000; k4=8000;  % Stiffness

% Bouc-Wen parameters
lambda=0.5; atilde=0.5; acap=0.5; abar=1; nbar=3;

% Degradation parameters
alpha1=0.5; alpha2=0.5; alpha3=0.5; alpha4=2; gamma=1*10^-4; beta=3;

%  Noise parameters
sigb=0.01; sig1=0.01; sig2=0.01; sig3=0.01; sig4=0.01; sig5=0; sig6=0.005;   % sig5 = Noise in parameter z

T = 15; % Total time of integration
dt = 0.01; % Time step
t = 0:dt:T;    % Time vector
Nt = length(t)-1;
Nsamp = 10; % MC simulations

% b matrix
b = [0; sigb/mb; 0; sig1/m1; 0; sig2/m2; 0; sig3/m3; 0; sig4/m4; 0; sig6];    % 12 x 1
   
deltamat = [sqrt(dt)            0;
            dt^1.5/2    dt^1.5/(2*sqrt(3))];
% 
for j=1:Nsamp
    j
%    
    y = zeros(10,Nt);        % Final y = 12 x Nt
    y(11,1) = 0;
    y(12,1) = 0;   % Keep it like this and make changes while defining a.
    N=zeros(1,numel(t));
    N(1)=1;
%  
for i=1:Nt
    dZ = deltamat(2,:)*randn(2,7); % 1 x 7
    dZ(7)=abs(dZ(7));
    dW = (deltamat(1,:)*randn(2,7))';  % 1 x 7
    dW(7)=abs(dW(7));
    DW = [dW(1) dW(1) dW(2) dW(2) dW(3) dW(3) dW(4) dW(4) dW(5) dW(5) dW(6) dW(7)]';   % 12 x 1
    DZ = [dZ(1) dZ(1) dZ(2) dZ(2) dZ(3) dZ(3) dZ(4) dZ(4) dZ(5) dZ(5) dZ(6) dZ(7)]';   % 12 x 1
    I100 = dt^2/6*DW;
    I011 = DW.^2*dt/6-dt^2/6;
    
    % A martix
    A21 = -(k1+N(i)*lambda*kb)/mb; A22 = -(c1+cb)/mb; A23 = k1/mb; A24 = c1/mb; A211 = -N(i)*kb*(1-lambda)/mb;
    A41 = k1/m1; A42 =  c1/m1; A43 = -(k1+k2)/m1; A44 = -(c1+c2)/m1; A45 = k2/m1; A46 = c2/m1;
    A63 = k2/m2; A64 = c2/m2; A65 = -(k2+k3)/m2; A66 = -(c2+c3)/m2; A67 = k3/m2; A68 = c3/m2; 
    A85 = k3/m3; A86 = c3/m3; A87 = -(k3+k4)/m3; A88 = -(c3+c4)/m3; A89 = k4/m3; A810 = c4/m3;
    A107 = k4/m4; A108 = c4/m4; A109 = -k4/m4; A110 = -c4/m4;
    A112 = abar-atilde*(abs(y(11,i)))^nbar; A1111 = -acap*abs(y(2,i))*(abs(y(11,i))^(nbar-1));

    A = [  0    1    0    0    0    0   0    0    0    0    0 ;
          A21  A22  A23  A24   0    0   0    0    0    0   A211 ;
           0    0    0    1    0    0   0    0    0    0    0 ;
          A41  A42  A43  A44  A45  A46  0    0    0    0    0 ;
           0    0    0    0    0    1   0    0    0    0    0 ; 
           0    0   A63  A64  A65  A66 A67  A68   0    0    0 ;
           0    0    0    0    0    0   0    1    0    0    0 ;
           0    0    0    0   A85  A86 A87  A88  A89  A810  0 ;
           0    0    0    0    0    0   0    0    0    1    0 ;
           0    0    0    0    0    0  A107 A108 A109 A110  0 ;
           0   A112  0    0    0    0   0    0    0    0  A1111]; % 11 x 11
  
    a12 = gamma*((y(1,i))^2+(y(2,i))^2)^(beta/2);
   
    % Power terms for the degradation model :
    T1 = (y(1,i)^2+y(2,i)^2)^(beta/2);
    T2 = (y(1,i)^2+y(2,i)^2)^((beta-2)/2);
    T3 = (y(1,i)^2+y(2,i)^2)^((beta-4)/2);
    T4 = (y(1,i)^2+y(2,i)^2)^((beta-6)/2); 

   a = [A*y(1:11,i);a12];         % 12 x 1
   dA = A;                        % 11 x 11
   L1a = dA(1:10,1:10)*b(1:10);   % 11 x 1
   L1a11 = b(2)*(abar -atilde*(abs(y(11,i)))^nbar - acap*y(11,i)*(abs(y(11,i)))^(nbar-1)*sign(y(2,i)));
   L1a12 = gamma*b(2)*beta*y(2,i)*T2;
   L0a = dA(1:10,1:10)*a(1:10);   % 10 x 1
   L0a11 = a(2)*(abar -atilde*(abs(y(11,i)))^nbar - acap*y(11,i)*(abs(y(11,i)))^(nbar-1)*sign(y(2,i)))...
           - a(11)*(atilde*y(2,i)*nbar*(abs(y(11,i)))^(nbar-1)*sign(y(11,i)) + acap*abs(y(2,i))*(abs(y(11,i)))^(nbar-1)...
           + acap*abs(y(2,i))*y(11,i)*(nbar-1)*(abs(y(11,i)))^(nbar-2)*sign(y(11,i)))...
           - (b(2))^2*acap*y(11,i)*(abs(y(11,i)))^(nbar-1)*diracdelta(y(2,i));
   
   L0L1a11 = -b(2)*(a(11)*atilde*nbar*(abs(y(11,i)))^(nbar-1)*sign(y(11,i)) + 2*a(2)*acap*y(11,i)*(abs(y(11,i)))^(nbar-1)*diracdelta(y(2,i))...
             + a(11)*acap*sign(y(2,i))*((abs(y(11,i)))^(nbar-1) - (nbar-1)*y(11,i)*(abs(y(11,i)))^(nbar-2)*sign(y(11,i)))...
             + (b(2))^2*acap*y(11,i)*(abs(y(11,i)))^(nbar-1)*diracdelta(y(2,i)));  % differentiation of diracdelta of y2 is written as herein
         
   L1L0a = A(1:10,1:10)*L1a(1:10);    % 10 x 1
   L1L1a11 = -2*(b(2))^2*(acap*y(11,i)*(abs(y(11,i)))^(nbar-1)*diracdelta(y(2,i)));
   L1L0a11 = -(b(2))^3*acap*y(11,i)*(abs(y(11,i)))^(nbar-1)*diracdelta(y(2,i))...  % differentiation of diracdelta of y2 is written as herein
             + b(2)*(-2*abar*atilde*nbar*y(2,i)*(abs(y(11,i)))^(nbar-1)*sign(y(11,i))...
             - (abs(y(2,i))+y(2,i)*sign(y(2,i)))*(abar*acap*(abs(y(11,i)))^(nbar-1)...
             + abar*acap*y(11,i)*(nbar-1)*(abs(y(11,i)))^(nbar-2)*sign(y(11,i))...
             - atilde*acap*(abs(y(11,i)))^(2*nbar-1)...
             - atilde*acap*(2*nbar-1)*y(11,i)*(abs(y(11,i)))^(2*nbar-2)*sign(y(11,i)))...
             + 2*atilde^2*y(2,i)*nbar*(abs(y(11,i)))^(2*nbar-1)*sign(y(11,i))...
             + 2*acap^2*y(11,i)*(abs(y(11,i)))^(2*nbar-2)*abs(y(2,i))*sign(y(2,i))...
             + 2*acap^2*(y(11,i))^2*(nbar-1)*abs(y(2,i))*sign(y(2,i))*(abs(y(11,i)))^(2*nbar-3)*sign(y(11,i)))...
             - 1/mb*(b(2)*cb*abar - b(2)*cb*atilde*(abs(y(11,i)))^nbar...
             - (sign(y(2,i))+2*y(2,i)*diracdelta(y(2,i)))*b(2)*acap*y(11,i)*(abs(y(11,i)))^(nbar-1)*(c1+cb)...
             + c1*abar*(b(2)-b(4)) + c1*atilde*(abs(y(11,i)))^nbar*(b(4)-b(2))...
             - k1*(y(1,i)-y(3,i))*acap*b(2)*y(11,i)*(abs(y(11,i)))^(nbar-1)*2*diracdelta(y(2,i))...
             + c1*acap*y(11,i)*(abs(y(11,i)))^(nbar-1)*(b(4)*sign(y(2,i))+b(2)*y(4,i)*2*diracdelta(y(2,i)))...
             - b(2)*2*diracdelta(y(2,i))*N(i)*kb*acap*(abs(y(11,i)))^(nbar-1)*y(11,i)*(lambda*y(1,i)+y(11,i)*(1-lambda)));
   
   if i==1
      L0a12 = a(1)*gamma*beta*y(1,i)*T2 + a(2)*gamma*beta*y(2,i)*T2 + 0.5*(b(2))^2*gamma*beta*(T2 + 0);
      L0L1a12 = b(2)*gamma*beta*(0 + a(2)*(T2 + 0) + 0 + 0);
      L1L0a12 = gamma*beta*y(1,i)*b(2)*(T2+0) + 0.5*gamma*beta*(b(2))^3*(0 + 0)...
             - gamma*beta/mb*((k1+N(i)*lambda*kb)*y(1,i)*b(2)*(T2+ 0) + (c1+cb)*b(2)*(2*T2*y(2,i)+0)...
             - k1*y(3,i)*b(2)*(T2+0)...
             - c1*(y(2,i)*T2*b(4)+y(4,i)*b(2)*(T2+0))...
             + N(i)*kb*(1-lambda)*y(11,i)*b(2)*(T2+0));
      L1L1a12 = gamma*beta*(b(2))^2*(T2+0);
   else
       L0a12 = a(1)*gamma*beta*y(1,i)*T2 + a(2)*gamma*beta*y(2,i)*T2 + 0.5*(b(2))^2*gamma*beta*(T2 + (beta-2)*(y(2,i))^2*T3);
       L0L1a12 = b(2)*gamma*beta*(a(1)*y(1,i)*y(2,i)*(beta-2)*T3 + a(2)*(T2 + (beta-2)*(y(2,i))^2*T3)...
             + 0.5*(b(2))^2*((beta-2)*y(2,i)*T3 + 2*(beta-2)*y(2,i)*T3 + (beta-2)*(beta-4)*y(2,i)^3*T4));      

       L1L0a12 = gamma*beta*y(1,i)*b(2)*(T2+(beta-2)*y(2,i)^2*T3)...
             + 0.5*gamma*beta*(b(2))^3*(3*(beta-2)*y(2,i)*T3 + (beta-2)*(beta-4)*y(2,i)^3*T4)...
             - gamma*beta/mb*((k1+N(i)*lambda*kb)*y(1,i)*b(2)*(T2+(beta-2)*y(2,i)^2*T3) + (c1+cb)*b(2)*(2*T2*y(2,i)+(beta-2)*y(2,i)^2*T3)...
             - k1*y(3,i)*b(2)*(T2+(beta-2)*y(2,i)^2*T3)...
             - c1*(y(2,i)*T2*b(4)+y(4,i)*b(2)*(T2+(beta-2)*y(2,i)^2*T3))...
             + N(i)*kb*(1-lambda)*y(11,i)*b(2)*(T2+(beta-2)*y(2,i)^2*T3));
       L1L1a12 = gamma*beta*(b(2))^2*(T2+(beta-2)*y(2,i)^2*T3);
   end
   
    y(1:10,i+1) = y(1:10,i) + a(1:10)*dt + b(1:10).*DW(1:10) + L1a(1:10).*DZ(1:10) + 0.5*L0a*dt^2 + L1L0a.*I100(1:10) ; 
    y(11,i+1) = y(11,i) + a(11)*dt + b(11)*DW(11) + L1a11*DZ(11) + 0.5*L0a11*dt^2 + (L0L1a11+L1L0a11)*I100(11) + L1L1a11*I011(11);
    y(12,i+1) = y(12,i) + a12*dt + b(12)*DW(12) + L1a12*DZ(12) + 0.5*L0a12*dt^2 + (L0L1a12+L1L0a12)*I100(12) + L1L1a12*I011(12);

    N(i+1) = alpha1 + alpha2.*exp(-alpha3.*y(12,i).^alpha4);
end
% Storage of variables,
Y1(j,:) = y(1,:);Y2(j,:) = y(2,:);
Y3(j,:) = y(3,:);Y4(j,:) = y(4,:);
Y5(j,:) = y(5,:);Y6(j,:) = y(6,:);
Y7(j,:) = y(7,:);Y8(j,:) = y(8,:);
Y9(j,:) = y(9,:);Y10(j,:) = y(10,:);
Y11(j,:) = y(11,:);Y12(j,:) = y(12,:);
DT(j,:)= N;        % degradation function
% 
 end
% 
% Sample solution of the Monte Carlo prediction :
u(1,:)= mean(Y1,1);   
u(2,:)= mean(Y3,1);   
u(3,:)= mean(Y5,1);  
u(4,:)= mean(Y7,1);   
u(5,:)= mean(Y9,1);   
u(6,:)= mean(Y11,1);
%
% Plotting commands ::
% ------------------------------------------------------------------------
figure(1); suptitle('Displacement plot for 5dof degrading system'),
subplot(3,2,1),plot(t,u(1,:),'--k'); hold on; xlabel('Time (sec)'); ylabel('E[Y]^{u1}'); 
subplot(3,2,2),plot(t,u(2,:),'--k'); hold on; xlabel('Time (sec)'); ylabel('E[Y]^{u2}');
subplot(3,2,3),plot(t,u(3,:),'--k'); hold on; xlabel('Time (sec)'); ylabel('E[Y]^{u3}'); 
subplot(3,2,4),plot(t,u(4,:),'--k'); hold on; xlabel('Time (sec)'); ylabel('E[Y]^{u4}'); 
subplot(3,2,5),plot(t,u(5,:),'--k'); hold on; xlabel('Time (sec)'); ylabel('E[Y]^{u5}'); 
% 
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Strong order 1.0 Milstein scheme
%                            dt = 0.0001
% -----------------------------------------------------------------------
clc;
clear;

% System parameters
mb=20; m1=20; m2=20; m3=20; m4=20;  % Mass
cb=10; c1=10; c2=10; c3=10; c4=10;  % Damping
kb=8000; k1=8000; k2=8000; k3=8000; k4=8000;  % Stiffness

% Bouc-Wen parameters
  lambda=0.5; atilde=0.5; acap=0.5; abar=1; nbar=3;

% Degradation parameters
alpha1=0.5; alpha2=0.5; alpha3=0.5; alpha4=2; 
gamma=1*10^-4; beta=3;

%  Noise parameters
   sigb=0.01; sig1=0.01; sig2=0.01; sig3=0.01; sig4=0.01; sig5=0; sig6=0.005;   % sig5 = Noise in parameter z

T =15; % Total time of integration
dt = 0.0001; % Time step
t = 0:dt:T;    % Time vector
Nt = length(t)-1;
Nsamp = 10; % MC simulations

% b matrix
b = [0; sigb/mb; 0; sig1/m1; 0; sig2/m2; 0; sig3/m3; 0; sig4/m4; 0; sig6];    % 12 x 1
   
deltamat = [sqrt(dt)            0;
            dt^1.5/2    dt^1.5/(2*sqrt(3))];
% 
for j=1:Nsamp
    j
%    
    y = zeros(10,Nt);        % Final y = 12 x Nt
    y(11,1) = 0;
    y(12,1) = 0;   % Keep it like this and make changes while defining a.
    N=zeros(1,numel(t));
    N(1)=1;
%  
for i=1:Nt
    dZ = deltamat(2,:)*randn(2,7); % 1 x 7
    dZ(7)=abs(dZ(7));
    dW = (deltamat(1,:)*randn(2,7))';  % 1 x 7
    dW(7)=abs(dW(7));
    DW = [dW(1) dW(1) dW(2) dW(2) dW(3) dW(3) dW(4) dW(4) dW(5) dW(5) dW(6) dW(7)]';   % 12 x 1
    DZ = [dZ(1) dZ(1) dZ(2) dZ(2) dZ(3) dZ(3) dZ(4) dZ(4) dZ(5) dZ(5) dZ(6) dZ(7)]';   % 12 x 1
    I100 = dt^2/6*DW;
    I011 = DW.^2*dt/6-dt^2/6;
    
    % A martix
    A21 = -(k1+N(i)*lambda*kb)/mb; A22 = -(c1+cb)/mb; A23 = k1/mb; A24 = c1/mb; A211 = -N(i)*kb*(1-lambda)/mb;
    A41 = k1/m1; A42 =  c1/m1; A43 = -(k1+k2)/m1; A44 = -(c1+c2)/m1; A45 = k2/m1; A46 = c2/m1;
    A63 = k2/m2; A64 = c2/m2; A65 = -(k2+k3)/m2; A66 = -(c2+c3)/m2; A67 = k3/m2; A68 = c3/m2; 
    A85 = k3/m3; A86 = c3/m3; A87 = -(k3+k4)/m3; A88 = -(c3+c4)/m3; A89 = k4/m3; A810 = c4/m3;
    A107 = k4/m4; A108 = c4/m4; A109 = -k4/m4; A110 = -c4/m4;
    A112 = abar-atilde*(abs(y(11,i)))^nbar; A1111 = -acap*abs(y(2,i))*(abs(y(11,i))^(nbar-1));

    A = [  0    1    0    0    0    0   0    0    0    0    0 ;
          A21  A22  A23  A24   0    0   0    0    0    0   A211 ;
           0    0    0    1    0    0   0    0    0    0    0 ;
          A41  A42  A43  A44  A45  A46  0    0    0    0    0 ;
           0    0    0    0    0    1   0    0    0    0    0 ; 
           0    0   A63  A64  A65  A66 A67  A68   0    0    0 ;
           0    0    0    0    0    0   0    1    0    0    0 ;
           0    0    0    0   A85  A86 A87  A88  A89  A810  0 ;
           0    0    0    0    0    0   0    0    0    1    0 ;
           0    0    0    0    0    0  A107 A108 A109 A110  0 ;
           0   A112  0    0    0    0   0    0    0    0  A1111]; % 11 x 11
  
    a12 = gamma*((y(1,i))^2+(y(2,i))^2)^(beta/2);
   
    % Power terms for the degradation model :
    T1 = (y(1,i)^2+y(2,i)^2)^(beta/2);
    T2 = (y(1,i)^2+y(2,i)^2)^((beta-2)/2);
    T3 = (y(1,i)^2+y(2,i)^2)^((beta-4)/2);
    T4 = (y(1,i)^2+y(2,i)^2)^((beta-6)/2); 

   a = [A*y(1:11,i);a12];         % 12 x 1
   dA = A;                        % 11 x 11               
   
    y(1:10,i+1) = y(1:10,i) + a(1:10)*dt + b(1:10).*DW(1:10); 
    y(11,i+1) = y(11,i) + a(11)*dt + b(11)*DW(11);
    y(12,i+1) = y(12,i) + a12*dt + b(12)*DW(12);

    N(i+1) = alpha1 + alpha2.*exp(-alpha3.*y(12,i).^alpha4);
end
% Storage of variables,
Y1(j,:) = y(1,:);
Y2(j,:) = y(2,:);
Y3(j,:) = y(3,:);
Y4(j,:) = y(4,:);
Y5(j,:) = y(5,:);
Y6(j,:) = y(6,:);
Y7(j,:) = y(7,:);
Y8(j,:) = y(8,:);
Y9(j,:) = y(9,:);
Y10(j,:) = y(10,:);
Y11(j,:) = y(11,:);
Y12(j,:) = y(12,:);
DT(j,:)= N;        % degradation function
% 
 end
% 
% Sample solution of the Monte Carlo prediction :
u(1,:)= mean(Y1,1);   
u(2,:)= mean(Y3,1);   
u(3,:)= mean(Y5,1);   
u(4,:)= mean(Y7,1);   
u(5,:)= mean(Y9,1);   
u(6,:)= mean(Y11,1);
%
% Plotting commands ::
% ------------------------------------------------------------------------
figure(1); 
subplot(3,2,1),plot(t,u(1,:),'r'); hold on; 
subplot(3,2,2),plot(t,u(2,:),'r'); hold on; 
subplot(3,2,3),plot(t,u(3,:),'r'); hold on; 
subplot(3,2,4),plot(t,u(4,:),'r'); hold on; 
subplot(3,2,5),plot(t,u(5,:),'r'); hold on; 
% 
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Strong order 1.0 Milstein scheme
%                            dt = 0.001
% -----------------------------------------------------------------------
% 
clc;
clear;

% System parameters
mb=20; m1=20; m2=20; m3=20; m4=20;  % Mass
cb=10; c1=10; c2=10; c3=10; c4=10;  % Damping
kb=8000; k1=8000; k2=8000; k3=8000; k4=8000;  % Stiffness

% Bouc-Wen parameters
  lambda=0.5; atilde=0.5; acap=0.5; abar=1; nbar=3;

% Degradation parameters
alpha1=0.5; alpha2=0.5; alpha3=0.5; alpha4=2; gamma=1*10^-4; beta=3;

%  Noise parameters
   sigb=0.01; sig1=0.01; sig2=0.01; sig3=0.01; sig4=0.01; sig5=0; sig6=0.005;   % sig5 = Noise in parameter z

T =15; % Total time of integration
dt = 0.0015; % Time step
t = 0:dt:T;    % Time vector
Nt = length(t)-1;
Nsamp = 10; % MC simulations

% b matrix
b = [0; sigb/mb; 0; sig1/m1; 0; sig2/m2; 0; sig3/m3; 0; sig4/m4; 0; sig6];    % 12 x 1
   
deltamat = [sqrt(dt)            0;
            dt^1.5/2    dt^1.5/(2*sqrt(3))];
% 
for j=1:Nsamp
    j
%    
    y = zeros(10,Nt);        % Final y = 12 x Nt
    y(11,1) = 0;
    y(12,1) = 0;   % Keep it like this and make changes while defining a.
    N=zeros(1,numel(t));
    N(1)=1;
%  
for i=1:Nt
    dZ = deltamat(2,:)*randn(2,7); % 1 x 7
    dZ(7)=abs(dZ(7));
    dW = (deltamat(1,:)*randn(2,7))';  % 1 x 7
    dW(7)=abs(dW(7));
    DW = [dW(1) dW(1) dW(2) dW(2) dW(3) dW(3) dW(4) dW(4) dW(5) dW(5) dW(6) dW(7)]';   % 12 x 1
    DZ = [dZ(1) dZ(1) dZ(2) dZ(2) dZ(3) dZ(3) dZ(4) dZ(4) dZ(5) dZ(5) dZ(6) dZ(7)]';   % 12 x 1
    I100 = dt^2/6*DW;
    I011 = DW.^2*dt/6-dt^2/6;
    
    % A martix
    A21 = -(k1+N(i)*lambda*kb)/mb; A22 = -(c1+cb)/mb; A23 = k1/mb; A24 = c1/mb; A211 = -N(i)*kb*(1-lambda)/mb;
    A41 = k1/m1; A42 =  c1/m1; A43 = -(k1+k2)/m1; A44 = -(c1+c2)/m1; A45 = k2/m1; A46 = c2/m1;
    A63 = k2/m2; A64 = c2/m2; A65 = -(k2+k3)/m2; A66 = -(c2+c3)/m2; A67 = k3/m2; A68 = c3/m2; 
    A85 = k3/m3; A86 = c3/m3; A87 = -(k3+k4)/m3; A88 = -(c3+c4)/m3; A89 = k4/m3; A810 = c4/m3;
    A107 = k4/m4; A108 = c4/m4; A109 = -k4/m4; A110 = -c4/m4;
    A112 = abar-atilde*(abs(y(11,i)))^nbar; A1111 = -acap*abs(y(2,i))*(abs(y(11,i))^(nbar-1));

    A = [  0    1    0    0    0    0   0    0    0    0    0 ;
          A21  A22  A23  A24   0    0   0    0    0    0   A211 ;
           0    0    0    1    0    0   0    0    0    0    0 ;
          A41  A42  A43  A44  A45  A46  0    0    0    0    0 ;
           0    0    0    0    0    1   0    0    0    0    0 ; 
           0    0   A63  A64  A65  A66 A67  A68   0    0    0 ;
           0    0    0    0    0    0   0    1    0    0    0 ;
           0    0    0    0   A85  A86 A87  A88  A89  A810  0 ;
           0    0    0    0    0    0   0    0    0    1    0 ;
           0    0    0    0    0    0  A107 A108 A109 A110  0 ;
           0   A112  0    0    0    0   0    0    0    0  A1111]; % 11 x 11
  
    a12 = gamma*((y(1,i))^2+(y(2,i))^2)^(beta/2);
   
    % Power terms for the degradation model :
    T1 = (y(1,i)^2+y(2,i)^2)^(beta/2);
    T2 = (y(1,i)^2+y(2,i)^2)^((beta-2)/2);
    T3 = (y(1,i)^2+y(2,i)^2)^((beta-4)/2);
    T4 = (y(1,i)^2+y(2,i)^2)^((beta-6)/2); 

   a = [A*y(1:11,i);a12];         % 12 x 1
   dA = A;                        % 11 x 11               
   
    y(1:10,i+1) = y(1:10,i) + a(1:10)*dt + b(1:10).*DW(1:10); 
    y(11,i+1) = y(11,i) + a(11)*dt + b(11)*DW(11);
    y(12,i+1) = y(12,i) + a12*dt + b(12)*DW(12);

    N(i+1) = alpha1 + alpha2.*exp(-alpha3.*y(12,i).^alpha4);
end
% Storage of variables,
Y1(j,:) = y(1,:);
Y2(j,:) = y(2,:);
Y3(j,:) = y(3,:);
Y4(j,:) = y(4,:);
Y5(j,:) = y(5,:);
Y6(j,:) = y(6,:);
Y7(j,:) = y(7,:);
Y8(j,:) = y(8,:);
Y9(j,:) = y(9,:);
Y10(j,:) = y(10,:);
Y11(j,:) = y(11,:);
Y12(j,:) = y(12,:);
DT(j,:)= N;        % degradation function
% 
 end
% 
% Sample solution of the Monte Carlo prediction :
u(1,:)= mean(Y1,1);   
u(2,:)= mean(Y3,1);   
u(3,:)= mean(Y5,1);   
u(4,:)= mean(Y7,1);   
u(5,:)= mean(Y9,1);   
u(6,:)= mean(Y11,1);
% 
% Plotting commands ::
% ------------------------------------------------------------------------
figure(1);
subplot(3,2,1),plot(t,u(1,:),'-.g'); 
subplot(3,2,2),plot(t,u(2,:),'-.g');
subplot(3,2,3),plot(t,u(3,:),'-.g'); 
subplot(3,2,4),plot(t,u(4,:),'-.g');
subplot(3,2,5),plot(t,u(5,:),'-.g');
% 
% ++++++++++++++++++++++++++++++++ END +++++++++++++++++++++++++++++++++++
% 