function [f,s]=fftplot(Ts,Input)
% function [f,s]=fftplot(Ts,Input)
L=length(Input);
Fs=1/Ts; % sampling frequency
NFFT = 2^nextpow2(L); % Next power of 2 from length of y
UT = fft(Input,NFFT)/L;
f = Fs/2*linspace(0,1,NFFT/2);
% % Plot single-sided amplitude spectrum.
s=(2*abs(UT(1:NFFT/2)))/(2*pi);

