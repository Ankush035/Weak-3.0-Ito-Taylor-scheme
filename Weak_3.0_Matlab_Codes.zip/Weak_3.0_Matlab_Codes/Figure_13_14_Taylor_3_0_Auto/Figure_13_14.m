%     Response simulation using Automated Weak 3.0 Ito-Taylor scheme
% ........................................................................
% Note: The code is developed for two cases that requires independent runs
% Two independent demo is given in this code,
% 
% (To run the desired case please uncomment respective sections:
% Case:1, Linear M-DOF system with intermediate floor degradation,
% (line 52,53,54,65,80,81,82,83,116)
% 
% Fig 13: Displacement response of the first ninth floor of the 10-DOF system
% Fig 14: Variation of Stiffness with time for the degrading 10 DOF Structural System
% 
% Case:2, Base isolated system with degrading hysteresis,
% (line 58,59,60,61,66,88,89,90,91,117)
% 
% .......................................................................
% The algorithm is demonstrated using a 10 -DOF shear frame system with
% degradation on sixth floor. The system is excited by Gaussian White
% Noise. (see Figure 12)
% 
% Author: Tapas Tripura, Ankush Gogoi, Budhaditya Hazra
% Indian Institute of Technology Guwahati, Assam, India
% 
% ***********************************************************************
% 
clear
clc
close all
warning off
% 
% Simulation :
Nsim = 20;  % Number Monte Carlo Simulation,
dt = 0.01;  % Time step, reduce in case of numerical instability
T = 100;    % Duration of simulation,
time = 0:dt:T;  % Time vector,
t = time;
Nt = length(time);
% 
% Simulation starts here :
for MC= 1:Nsim % MC = number of Monte Carlo,                                                          
    MC      
%     
% ||||||||||||||||||||||||||||||| INPUT ||||||||||||||||||||||||||||||||
% System parameters, (use arrays for differential parameters)
    dof = 10;                   % Number of degree-of-freedom,
    DF = 1;
    m = 10;                     % identical properties, subjected to change
    ms = linspace(m,m,dof);     % mass of the system,
    kk = 8000;
    ks = linspace(kk,kk,dof);   % stiffness of the system,
    cc = 6;
    cs = linspace(cc,cc,dof);   % damping of the system,
%     
% Diffusion coefficients at individual floors,
    sig = 4*linspace(0.5,1,dof); sig(DF) = 6; sig(dof+1)=0.002;
    b = [0; sig(1); 0; sig(2); 0; sig(3); 0; sig(4); 0; sig(5); 0; sig(6); 0;...
         sig(7); 0; sig(8); 0; sig(9); 0; sig(10); sig(11)];
%      
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~ System Cases ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%           Uncomment the corresponding cases in the interest,
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% --- Case:1, Linear M-DOF system with intermediate floor degradation ---
% Define degradation parameters ::
% --------------------------------------------------------------
    ID = 2;
    gamma = 1*10^-4; beta = 3;
    alpha1 = 0.6; alpha2 = 0.4; alpha3 = 0.7; alpha4 = 2.0;
% --------------------------------------------------------------
% --- Case:2, Base isolated system with degrading hysteresis ---
% --------------------------------------------------------------
% % %     ID = 1;
% % %     gamma = 1*10^-4; beta = 3;
% % %     alpha1 = 0.6; alpha2 = 0.4; alpha3 = 0.7; alpha4 = 2.0;
% % %     abar = 1; atilde = 0.5; nbar = 3; acap = 0.5; lambda = 0.5;
% --------------------------------------------------------------
% ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
% Initialisation of the state variables,
    y = zeros(2*dof+1,Nt);   % system states for case 1,
%     y = zeros(2*dof+2,Nt);   % system states for case:2,
    N = zeros(1,Nt);         % degradation,
    N(1) = 1;                % initial value for degradation,
%     
% Time Integration of response :: 
for n = 1:Nt-1
% 
% Multiple stochastic Integrals ::
    [Is,Iw,Iww,Iws,Isw,Iss,Iwss,Isww,Iwww,Isss]= msi(ID,dt,dof);
%     
% Ito-Taylor expansion ::
% ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
%    Case 1: Linear M-DOF system with intermediate floor degradation
% ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    [A,AA,Bbar] = itosde(ID,dof,ms,ks,cs,N(n),gamma,beta,DF,sig,y(:,n));
    [dA,dAt,ddA,L1ab,L0ab,L1L1ab,L0L1ab,L1L0ab]=hom1(ID,dof,ms,ks,cs,N(n),DF,y(:,n),A,Bbar);
    [Lja,L0a,L1L0a,Bb]= hom2(sig,ms,dA,dAt,ddA,A,AA,Bbar,dof);
    [L1ad,L0ad,L0L1ad,L1L1ad,L1L0ad]=hom_deg(ID,dof,ms,ks,cs,A,gamma,beta,N(n),b,DF,y(:,n),n); 
    
% ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
%          Case 2: Base isolated system with degrading hysteresis
% ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
% %     [A,AA,Bbar] = itosde(ID,dof,ms,ks,cs,N(n),gamma,beta,DF,sig,y(:,n),abar,atilde,nbar,acap,lambda);
% %     [dA,dAt,ddA,L1ab,L0ab,L1L1ab,L0L1ab,L1L0ab]=hom1(ID,dof,ms,ks,cs,N(n),DF,y(:,n),A,b,abar,atilde,nbar,acap,lambda);
% %     [Lja,L0a,L1L0a,Bb]= hom2(sig,ms,dA,dAt,ddA,A,AA,Bbar,dof);
% %     [L1ad,L0ad,L0L1ad,L1L1ad,L1L0ad]=hom_deg(ID,dof,ms,ks,cs,A,gamma,beta,N(n),b,DF,y(:,n),n,lambda); 
%     
% Weak 3.0 ITO-Taylor governing equation in matrix form ::
    y(1:2*dof,n+1) = y(1:2*dof,n) + A(1:2*dof)*Is + Bb.*Iw(1:2*dof) ...
        + Lja(1:2*dof).*Iws(1:2*dof) + 0.5*L0a(1:2*dof)*Is^2 + L1L0a.*Iwss(1:2*dof);
    y(2*dof+1,n+1) = y(2*dof+1,n) + A(2*dof+1)*Is + b(2*dof+1)*Iw(2*dof+1)...
        + L1ad*Iws(2*dof+1) + 0.5*L0ad*Is^2 +(L0L1ad + L1L0ad)*Iwss(2*dof+1) + L1L1ad*Isww(2*dof+1);
% 
% Degradation evolution equation ::
    N(n+1) = alpha1 + alpha2.*exp(-alpha3.*y(2*dof+1,n+1).^alpha4);
% 
end    % Time integration for response is over here,
% 
% Storage of states in every simulation ::
flag = 0; count = 0;
for i=1:(2*dof)
    if mod(i,2)==1
        count = count+1;
        u(count,:,MC)= y(i,:);  % displacement response,
    elseif mod(i,2)==0
        flag = flag+1;
        udot(flag,:,MC)= y(i,:);   % velocity response, 
    end
end
% 
psi(MC,:)= y(2*dof+1,:);  % envelope function for linear system,
% Z(MC,:)= y(2*dof+2,:);  % envelope function for BW oscillator,
DT(MC,:)= N;    % Exponential growth of degradation,
%         
end
% 
figure, plot(t,mean(DT));
xlabel('Time (s)'); ylabel('Degradation function');
title('Evolution of degradation');
% 
figure, plot(t,(mean(DT).*kk));
xlabel('Time (s)'); ylabel('K_6 in N/m');
title('State of stiffness');
% 
% Ensemble mean of the system states ::
um= mean(u,3); udotm= mean(udot,3); 
figure, suptitle('Displacement Trajectory');
for i=1:9
    subplot(3,3,i), plot(t,um(i,:));
    xlabel('Time (s)'); ylabel(['E[X^' num2str(i) '] (m)']);
end
% 
% END
% =======================================================================
% 