function [dA,dAt,ddA,L1ab,L0ab,L1L1ab,L0L1ab,L1L0ab]=hom1(ID,dof,ms,ks,cs,Nn,DF,yn,An,b,Ab,Be,Nb,Ga,La)
%
% hom_deg.m, computes the higher order moments for the Ito-diffuison form
% of degradation function,
% function [L1ad,L0ad,L0L1ad,L1L1ad,L1L0ad]=hom_deg(ID,dof,ms,ks,cs,An,C1,mbar,Nn,b,DF,yn,n,La)
% 
% Computation of the higher order moments for degradation :
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Input variables:
% ID = simulation case,
% dof = degree-of-freedom,
% ms = mass at each degree-of-freedom,
% ks = stiffness at each degree-of-freedom,
% cs = damping at each degree-of-freedom,
% Nn = degradation evolution at each instant of time,
% DF = number of degrading floor,
% yn = system states at each degree-of-freedom,
% An = drift at each instant of time,
% b = dispersion coefficient for each state of the system, 
% Ab, Be, Ga = shape parameters of the bouc-wen system, 
% Nb = exponential parameter controlling the transition from 
% elastic to post-elastic branch,
% La = proportion of elastic to hysteresis force,
% 
% Output variables:
% dA = Jacobian of the drift terms,
% dAt = time derivative of the drift terms,
% ddA = Hessian matrix of the drift terms,
% L1ad, L0ad, L0L1ad, L1L1ad, L1L0ad = higher order moments for degradation
% function.
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% 
if nargin == 10
    Abar = [];
    beta = [];
    nbar = [];
    gamma = [];
    lambda = [];
else
    Abar = Ab;
    beta = Be;
    nbar = Nb;
    gamma = Ga;
    lambda = La;
end
% 
switch ID
    case 1
    [dA,dAt,ddA,L1ab,L0ab,L1L1ab,L0L1ab,L1L0ab]=bw(dof,ms,ks,cs,Nn,DF,yn,An,b,Abar,beta,nbar,gamma,lambda);
%     
    case 2
    [dA,dAt,ddA,L1ab,L0ab,L1L1ab,L0L1ab,L1L0ab]=linr(dof,ms,ks,cs,Nn,DF,yn,An,b,Abar,beta,nbar,gamma,lambda);
end
% 
% sub-routine 1:
function [dA,dAt,ddA,L1ab,L0ab,L1L1ab,L0L1ab,L1L0ab]= bw(dof,ms,ks,cs,Nn,DF,yn,An,b,Abar,beta,nbar,gamma,lambda)
% First derivative matrix (evaluated on drift) :: 
DF = 1;
Nk = 2*length(ks);
dA = zeros(2*dof,2*dof);
% 
for i=1:Nk
    if mod(i,2) == 1 && i==1 %number is even else %number is odd end
        dA(i,(2*i)) = 1;
    elseif mod(i,2) == 1
        dA(i,i+1) = 1;
    else
        if (i/2)==1
            dA(i,1)= -(Nn*lambda*ks(i/2)+ks((i/2)+1))/ms(i/2);
            dA(i,2)= -(cs(i/2)+cs((i/2)+1))/ms(i/2);
            dA(i,3)= ks((i/2)+1)/ms(i/2);                                                                                                                                                                                                                                                                                                                                                                                                                   
            dA(i,4)= cs((i/2)+1)/ms(i/2);
        elseif i==Nk
            dA(i,i)= -cs(i/2)/ms(i/2);
            dA(i,i-1)= -ks(i/2)/ms(i/2);
            dA(i,i-2)= cs(i/2)/ms(i/2);
            dA(i,i-3)= ks(i/2)/ms(i/2);
        else
            dA(i,i)= -(cs(i/2)+cs((i/2)+1))/ms(i/2);
            dA(i,i-1)= -(ks(i/2)+ks((i/2)+1))/ms(i/2);
            dA(i,i-2)= cs(i/2)/ms(i/2);
            dA(i,i-3)= ks(i/2)/ms(i/2);
            dA(i,i+1)= ks((i/2)+1)/ms(i/2);
            dA(i,i+2)= cs((i/2)+1)/ms(i/2);
        end
    end
end
dAt = zeros(2*dof,1); %%%%%%% time drivative term,

ddA = zeros(2*dof,1); %%%%%%% second derivative term,
%
L1ab = b(2*DF)/ms(DF)*(Abar -beta*(abs(yn(2*dof+1)))^nbar - gamma*yn(2*dof+1)*(abs(yn(2*dof+1)))^(nbar-1)*sign(yn(2*DF)));
L0ab = An(2*DF)*(Abar -beta*(abs(yn(2*dof+1)))^nbar - gamma*yn(2*dof+1)*(abs(yn(2*dof+1)))^(nbar-1)*sign(yn(2*DF)))...
       - An(2*dof+1)*(beta*yn(2*DF)*nbar*(abs(yn(2*dof+1)))^(nbar-1)*sign(yn(2*dof+1)) + gamma*abs(yn(2*DF))*(abs(yn(2*dof+1)))^(nbar-1)...
       + gamma*abs(yn(2*DF))*yn(2*dof+1)*(nbar-1)*(abs(yn(2*dof+1)))^(nbar-2)*sign(yn(2*dof+1)))...
       - (b(2*DF)/ms(DF))^2*gamma*yn(2*dof+1)*(abs(yn(2*dof+1)))^(nbar-1)*diracdelta(yn(2*DF));
L1L1ab = -2*(b(2*DF)/ms(DF))^2*(gamma*yn(2*dof+1)*(abs(yn(2*dof+1)))^(nbar-1)*diracdelta(yn(2*DF)));
L0L1ab = -b(2*DF)/ms(DF)*(An(2*dof+1)*beta*nbar*(abs(yn(2*dof+1)))^(nbar-1)*sign(yn(2*dof+1)) + 2*An(2*DF)*gamma*yn(2*dof+1)*(abs(yn(2*dof+1)))^(nbar-1)*diracdelta(yn(2*DF))...
         + An(2*dof+1)*gamma*sign(yn(2*DF))*((abs(yn(2*dof+1)))^(nbar-1) - (nbar-1)*yn(2*dof+1)*(abs(yn(2*dof+1)))^(nbar-2)*sign(yn(2*dof+1)))...
         + (b(2*DF)/ms(DF))^2*gamma*yn(2*dof+1)*(abs(yn(2*dof+1)))^(nbar-1)*diracdelta(yn(2*DF)));  % differentiation of diracdelta of y2 is written as herein
L1L0ab = -(b(2*DF)/ms(DF))^3*gamma*yn(2*dof+1)*(abs(yn(2*dof+1)))^(nbar-1)*diracdelta(yn(2*DF))...  % differentiation of diracdelta of y2 is written as herein
         + b(2*DF)/ms(DF)*(-2*Abar*beta*nbar*yn(2*DF)*(abs(yn(2*dof+1)))^(nbar-1)*sign(yn(2*dof+1))...
         - (abs(yn(2*DF))+yn(2*DF)*sign(yn(2*DF)))*(Abar*gamma*(abs(yn(2*dof+1)))^(nbar-1)...
         + Abar*gamma*yn(2*dof+1)*(nbar-1)*(abs(yn(2*dof+1)))^(nbar-2)*sign(yn(2*dof+1))...
         - beta*gamma*(abs(yn(2*dof+1)))^(2*nbar-1)...
         - beta*gamma*(2*nbar-1)*yn(2*dof+1)*(abs(yn(2*dof+1)))^(2*nbar-2)*sign(yn(2*dof+1)))...
         + 2*beta^2*yn(2*DF)*nbar*(abs(yn(2*dof+1)))^(2*nbar-1)*sign(yn(2*dof+1))...
         + 2*gamma^2*yn(2*dof+1)*(abs(yn(2*dof+1)))^(2*nbar-2)*abs(yn(2*DF))*sign(yn(2*DF))...
         + 2*gamma^2*(yn(2*dof+1))^2*(nbar-1)*abs(yn(2*DF))*sign(yn(2*DF))*(abs(yn(2*dof+1)))^(2*nbar-3)*sign(yn(2*dof+1)))...
         - 1/ms(DF)*((b(2*DF)/ms(DF))*cs(DF)*Abar - (b(2*DF)/ms(DF))*cs(DF)*beta*(abs(yn(2*dof+1)))^nbar...
         - (sign(yn(2*DF))+2*yn(2*DF)*diracdelta(yn(2*DF)))*(b(2*DF)/ms(DF))*gamma*yn(2*dof+1)*(abs(yn(2*dof+1)))^(nbar-1)*(cs(DF+1)+cs(DF))...
         + cs(DF+1)*Abar*((b(2*DF)/ms(DF))-(b(2*(DF+1))/ms(DF+1))) + cs(DF+1)*beta*(abs(yn(2*dof+1)))^nbar*((b(2*(DF+1))/ms(DF+1))-(b(2*DF)/ms(DF)))...
         - ks(DF+1)*(yn(2*DF-1)-yn(2*DF+1))*gamma*(b(2*DF)/ms(DF))*yn(2*dof+1)*(abs(yn(2*dof+1)))^(nbar-1)*2*diracdelta(yn(2*DF))...
         + cs(DF+1)*gamma*yn(2*dof+1)*(abs(yn(2*dof+1)))^(nbar-1)*((b(2*(DF+1))/ms(DF+1))*sign(yn(2*DF))+(b(2*DF)/ms(DF))*yn(2*(DF+1))*2*diracdelta(yn(2*DF)))...
         - (b(2*DF)/ms(DF))*2*diracdelta(yn(2*DF))*Nn*ks(DF)*gamma*(abs(yn(2*dof+1)))^(nbar-1)*yn(2*dof+1)*(lambda*yn(2*DF-1)+yn(2*dof+1)*(1-lambda)));
%    
% sub-routine 2:
function [dA,dAt,ddA,L1ab,L0ab,L1L1ab,L0L1ab,L1L0ab]=linr(dof,ms,ks,cs,Nn,DF,yn,An,b,Abar,beta,nbar,gamma,lambda)
% First derivative matrix (evaluated on drift) :: 
%     
Nk = 2*length(ks);
dA = zeros(2*dof,2*dof);
for i=1:Nk
    if mod(i,2) == 1 && i==1 %number is even else %number is odd end
        dA(i,(2*i)) = 1;
    elseif mod(i,2) ==1
        dA(i,i+1) = 1;
    else
        if (i/2)==1
            dA(i,1)= -(ks(i/2)+ks((i/2)+1))/ms(i/2);
            dA(i,2)= -(cs(i/2)+cs((i/2)+1))/ms(i/2);
            dA(i,3)= ks((i/2)+1)/ms(i/2);                                                                                                                                                                                                                                                                                                                                                                                                                   
            dA(i,4)= cs((i/2)+1)/ms(i/2);
        elseif i==Nk
            dA(i,i)= -cs(i/2)/ms(i/2);
            dA(i,i-1)= -ks(i/2)/ms(i/2);
            dA(i,i-2)= cs(i/2)/ms(i/2);
            dA(i,i-3)= ks(i/2)/ms(i/2);
        elseif i==2*(DF-1)
            dA(i,i)= -(cs(i/2)+cs((i/2)+1))/ms(i/2);
            dA(i,i-1)= -(ks(i/2)+(Nn*ks((i/2)+1)))/ms(i/2);
            dA(i,i-2)= cs(i/2)/ms(i/2);
            dA(i,i-3)= ks(i/2)/ms(i/2);
            dA(i,i+1)= Nn*ks((i/2)+1)/ms(i/2);
            dA(i,i+2)= cs((i/2)+1)/ms(i/2);
        elseif i==2*DF
            dA(i,i)= -(cs(i/2)+cs((i/2)+1))/ms(i/2);
            dA(i,i-1)= -((Nn*ks(i/2))+ks((i/2)+1))/ms(i/2);
            dA(i,i-2)= cs(i/2)/ms(i/2);
            dA(i,i-3)= Nn*ks(i/2)/ms(i/2);
            dA(i,i+1)= ks((i/2)+1)/ms(i/2);
            dA(i,i+2)= cs((i/2)+1)/ms(i/2);
        else
            dA(i,i)= -(cs(i/2)+cs((i/2)+1))/ms(i/2);
            dA(i,i-1)= -(ks(i/2)+ks((i/2)+1))/ms(i/2);
            dA(i,i-2)= cs(i/2)/ms(i/2);
            dA(i,i-3)= ks(i/2)/ms(i/2);
            dA(i,i+1)= ks((i/2)+1)/ms(i/2);
            dA(i,i+2)= cs((i/2)+1)/ms(i/2);
        end
    end
end
dAt = zeros(2*dof,1); %%%%%%% time drivative term,

ddA = zeros(2*dof,1); %%%%%%% second derivative term,

L1ab = 0; L0ab = 0; L1L1ab = 0; L0L1ab = 0; L1L0ab = 0;
% These values are defined as null as they don't exist in case: 2