function [Lja,L0a,L1L0a,Bb]= hom2(sig,ms,dA,dAt,ddA,A,AA,Bbar,dof)
% hom.m, computes the higher order moments of the SDEs,
% function [Lja,L0a,L1L0a,Bb]= hom(sig,ms,dA,dAt,ddA,A,AA,Bbar,dof)
% 
% Computation of the higher order moments :
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Input variables:
% sig = Dispersion/force intensities at each degree-of-freedom,
% ms = mass vector (mass at each degree-of-freedom,
% dA = Jacobian of the drift terms,
% dAt = time derivative of the drift terms,
% ddA = Hessian matrix of the drift terms,
% A = drift at each instant of time,
% AA = drift coefficient matrix,
% Bbar = dispersion matrix,
% dof = degree-of-freedom,
% 
% Output variables:
% Lja = forst order stochastic moments for the dispersion terms,
% L0a = first order stochastic moments for the drift terms,
% L1L0a = second order stochastic moments for the SDE,
% Bb = Vector of diffusion coefficients at each degree-of-freedom,
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% 
Bb = zeros(2*dof,1);    % Initialization of the Diffusion matrix,
for i=1:dof
    Bb(2*i) = sig(i)/ms(i); % Diffusion matrix of the system,
end
% 
% Evaluation of the moments ::
for i=1:dof
    LJJa(:,i) = dA*Bbar(:,i);  % differential operator on diffusion,
end
    Lja = sum(LJJa,2);
    L0a = dAt + dA*A(1:2*dof) + ddA;  % differential operator on drift,   
    L1L0a = AA(2*dof,2*dof)*dA*Bb; 
%     