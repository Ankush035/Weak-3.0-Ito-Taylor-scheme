function [A,AA,Bbar]=itosde(ID,dof,ms,ks,cs,Nn,C1,mbar,DF,sig,yn,Ab,Be,Nb,Ga,La)
%
% drift_sde.m, computes the drift and diffusion of a SDE,
% function [Lja,L0a,L1L0a,Bb]= hom(sig,ms,dA,dAt,ddA,A,AA,Bbar,dof)
% 
% Computation of the MSIs :
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Input variables:
% ID = simulation case,
% dof = degree-of-freedom,
% ms = mass at each degree-of-freedom,
% ks = stiffness at each degree-of-freedom,
% cs = damping at each degree-of-freedom,
% Nn = degradation evolution at each instant of time,
% C1 = multiplicative parameter of degradation,
% mbar = exponential parameter of degradation,
% DF = number of degrading floor,
% sig = dispersion/force intensities at each degree-of-freedom,
% yn = system states at each degree-of-freedom,
% Ab, Be, Ga = shape parameters of the bouc-wen system, 
% Nb = exponential parameter controlling the transition from 
% elastic to post-elastic branch,
% La = proportion of elastic to hysteresis force,
% 
% Output variables:
% A = drift at each instant of time,
% AA = drift coefficient matrix,
% Bbar = dispersion matrix,
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% 
if nargin == 11
    Abar = [];
    beta = [];
    nbar = [];
    gamma = [];
    lambda = [];
else
    Abar = Ab;
    beta = Be;
    nbar = Nb;
    gamma = Ga;
    lambda = La;
end
% ......................................................................
switch ID
    case 1      
    [A,AA]=itobw(dof,ms,ks,cs,Nn,C1,mbar,DF,sig,yn,Abar,beta,nbar,gamma,lambda);
% 
    case 2
    [A,AA]=itolinr(dof,ms,ks,cs,Nn,C1,mbar,DF,sig,yn,Abar,beta,nbar,gamma,lambda);
end
% ........................................................................
% Dispersion coefficient matrix for the system :
Bb = zeros(dof,2*dof);
for i=1:dof
    Bb(i,2*i) = sig(i)/ms(i);
end
Bbar = Bb';
% 
% sub-routine 1:
function [A,AA]=itobw(dof,ms,ks,cs,Nn,C1,mbar,DF,sig,yn,Abar,beta,nbar,gamma,lambda)
% Drift coefficient matrix for base isolated system with base degradation :
AA = zeros(2*dof+1,2*dof+1);
Nk = 2*length(ks);
for i=1:Nk
    if mod(i,2) == 1 && i==1 %number is even else %number is odd end
        AA(i,(2*i)) = 1;
    elseif mod(i,2) ==1
        AA(i,i+1) = 1;
    else
        if (i/2)==1
            AA(i,1)= -(Nn*lambda*ks(i/2)+ks((i/2)+1))/ms(i/2);
            AA(i,2)= -(cs(i/2)+cs((i/2)+1))/ms(i/2);
            AA(i,3)= ks((i/2)+1)/ms(i/2);                                                                                                                                                                                                                                                                                                                                                                                                                   
            AA(i,4)= cs((i/2)+1)/ms(i/2);
            AA(i,2*dof+1) = -Nn*ks(i/2)*(1-lambda)/ms(i/2);
        elseif i==Nk
            AA(i,i)= -cs(i/2)/ms(i/2);
            AA(i,i-1)= -ks(i/2)/ms(i/2);
            AA(i,i-2)= cs(i/2)/ms(i/2);
            AA(i,i-3)= ks(i/2)/ms(i/2);
        else
            AA(i,i)= -(cs(i/2)+cs((i/2)+1))/ms(i/2);
            AA(i,i-1)= -(ks(i/2)+ks((i/2)+1))/ms(i/2);
            AA(i,i-2)= cs(i/2)/ms(i/2);
            AA(i,i-3)= ks(i/2)/ms(i/2);
            AA(i,i+1)= ks((i/2)+1)/ms(i/2);
            AA(i,i+2)= cs((i/2)+1)/ms(i/2);
        end
    end
end
    AA(2*dof+1,2)= Abar-beta*(abs(yn(2*dof+1)))^nbar;
    AA(2*dof+1,2*dof+1)= -gamma*abs(yn(2))*(abs(yn(2*dof+1)))^(nbar-1);
% 
    A2 = C1*(yn(1)^2+yn(2)^2)^(mbar/2);  
    A = [AA*yn(1:(2*dof+1));A2]; % drift at each time step,
%     
% sub-routine 2:
function [A,AA]=itolinr(dof,ms,ks,cs,Nn,C1,mbar,DF,sig,yn,Ab,Be,Nb,Ga,La)
% Drift coefficient matrix for linear shear frame with intermediate
% degrading floor:
AA = zeros(2*dof,2*dof);
Nk = 2*length(ks);
for i=1:Nk
    if mod(i,2) == 1 && i==1 %number is even else %number is odd end
        AA(i,(2*i)) = 1;
    elseif mod(i,2) ==1
        AA(i,i+1) = 1;
    else
        if (i/2)==1
            AA(i,1)= -(ks(i/2)+ks((i/2)+1))/ms(i/2);
            AA(i,2)= -(cs(i/2)+cs((i/2)+1))/ms(i/2);
            AA(i,3)= ks((i/2)+1)/ms(i/2);                                                                                                                                                                                                                                                                                                                                                                                                                   
            AA(i,4)= cs((i/2)+1)/ms(i/2);
        elseif i==Nk
            AA(i,i)= -cs(i/2)/ms(i/2);
            AA(i,i-1)= -ks(i/2)/ms(i/2);
            AA(i,i-2)= cs(i/2)/ms(i/2);
            AA(i,i-3)= ks(i/2)/ms(i/2);
        elseif i==2*(DF-1)
            AA(i,i)= -(cs(i/2)+cs((i/2)+1))/ms(i/2);
            AA(i,i-1)= -(ks(i/2)+(Nn*ks((i/2)+1)))/ms(i/2);
            AA(i,i-2)= cs(i/2)/ms(i/2);
            AA(i,i-3)= ks(i/2)/ms(i/2);
            AA(i,i+1)= Nn*ks((i/2)+1)/ms(i/2);
            AA(i,i+2)= cs((i/2)+1)/ms(i/2);
        elseif i==2*DF
            AA(i,i)= -(cs(i/2)+cs((i/2)+1))/ms(i/2);
            AA(i,i-1)= -((Nn*ks(i/2))+ks((i/2)+1))/ms(i/2);
            AA(i,i-2)= cs(i/2)/ms(i/2);
            AA(i,i-3)= Nn*ks(i/2)/ms(i/2);
            AA(i,i+1)= ks((i/2)+1)/ms(i/2);
            AA(i,i+2)= cs((i/2)+1)/ms(i/2);
        else
            AA(i,i)= -(cs(i/2)+cs((i/2)+1))/ms(i/2);
            AA(i,i-1)= -(ks(i/2)+ks((i/2)+1))/ms(i/2);
            AA(i,i-2)= cs(i/2)/ms(i/2);
            AA(i,i-3)= ks(i/2)/ms(i/2);
            AA(i,i+1)= ks((i/2)+1)/ms(i/2);
            AA(i,i+2)= cs((i/2)+1)/ms(i/2);
        end
    end
end
A2 = C1*(yn(2*DF-1)^2+yn(2*DF)^2)^(mbar/2);     
A = [AA*yn(1:(2*dof));A2];  % drift at each time step,