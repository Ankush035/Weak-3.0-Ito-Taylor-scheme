function [Is,Iw,Iww,Iws,Isw,Iss,Iwss,Isww,Iwww,Isss]= msi(ID,dt,dof)
% msi.m, computes the multiple stochastic integrals,
% function [Is,Iw,Iww,Iws,Isw,Iss,Iwss,Isww,Iwww,Isss]= msi(ID,dt,dof)
% 
% Computation of the MSIs :
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Input variables:
% ID = the case of the simulation,
% dt = time step,
% dof = degree-of-freedom of the shear frame,
% 
% Output variables:
% Is, Iw = First order MSIs,
% Iww, Iws, Isw, Iss = Second order MSIs,
% Iwss, Isww, Iwww, Isss = Third order MSIs,
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% 
% Brownian and MSI increaments (Eq. 23):
if ID == 1
    deltamat = [    sqrt(dt)             0;
                (dt^1.5)/2    (dt^1.5)/(2*sqrt(3))]*randn(2,2*dof+1);
    dW = deltamat(1,:)';
    dW(2*dof+2) = abs(dW(dof+2));
    dZ = deltamat(2,:)';    
    dZ(2*dof+2) = abs(dZ(dof+2));
else
    deltamat = [    sqrt(dt)             0;
                (dt^1.5)/2    (dt^1.5)/(2*sqrt(3))]*randn(2,2*dof+1);
    dW = deltamat(1,:)';
    dW(2*dof+1) = abs(dW(dof+1));
    dZ = deltamat(2,:)';    
    dZ(2*dof+1) = abs(dZ(dof+1));
end
% 
% Multiple stochastic Integrals (Eq. 22)::
    Is = dt; 
    Iw = dW; 
    Iww = ((dW.^2)-dt)/2; 
    Iws = dZ;
    Iss = (dt.^2)/2;
    Isw = (dW.*dt-dZ);
    Iwss = (dt^2/6)*dW;
    Isww = ((dW.^2)*dt)/6-(dt^2)/6;
    Iwww = (dW.^3)/6-(dW.*dt)/2;
    Isss = (dt^3)/6;
%     