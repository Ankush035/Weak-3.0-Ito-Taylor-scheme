% Fig 15: Response of the nonsmooth oscillator with linear elastic support
% 
%          Nonsmooth oscillator with linear elastic support
% 
% The analysis done for EM, Milstein and Weak 3.0 scheme
% The results are compared using dt=0.03 against a reference solution
% obtained by EM: dt=0.0001
% 
% Author: Tapas Tripura, Ankush Gogoi, Budhaditya Hazra
% Indian Institute of Technology Guwahati, Assam, India
% 
% ************************************************************************
clc
clear
close all
% 
w=2*pi; c=4; k=100; m=1; g=0.0045; cc=5; kc=200;
sig=0.01; P=4;   
%
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Order 0.5 Euler-Maruyama scheme
%                            dt = 0.0001
%                       Reference solution
% ------------------------------------------------------------------------
% 
dt=0.0001; 
T=10;
t=0:dt:T;   % time variable
Nt=numel(t);
%
% initial conditions
x_init=[0.1;0.1];
x(:,1)=x_init;
for i=1:Nt-1
%
    x1o=x(1,i);
    x2o=x(2,i);
% 
    A1 = x2o;
    A2 = (1/m)*(-c*x2o-2*k*x1o+P*cos(w*(i-1)*dt));
    Bb = sig/m;
    x1n=x1o+A1*dt;
    x2n=x2o+A2*dt + Bb*sqrt(dt)*randn;
% 
    if x1n>=g
        x2n=x2n+1/m*(-cc*x2o-kc*(x1n-g))*dt;
    end
% 
    x(:,i+1)=[x1n;x2n];
%
end
figure(1); plot(t,x(1,:),'r','linewidth',2); hold on;    
figure(2); plot(t,x(2,:),'r','linewidth',2); hold on;   
%
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Order 0.5 Euler-Maruyama scheme
%                            dt = 0.03
% ------------------------------------------------------------------------
% 
clear x
dt=0.03;   
t=0:dt:T;   % time variable
Nt=numel(t);
%
% initial conditions
x_init=[0.1;0.1];
x(:,1)=x_init;
for i=1:Nt-1
%  
    x1o=x(1,i);
    x2o=x(2,i);
% 
    A1 = x2o;
    A2 = (1/m)*(-c*x2o-2*k*x1o+P*cos(w*(i-1)*dt));
    Bb = sig/m;
    x1n=x1o+A1*dt;
    x2n=x2o+A2*dt + Bb*sqrt(dt)*randn;
% 
    if x1n>=g
        x2n=x2n+1/m*(-cc*x2o-kc*(x1n-g))*dt;
    end
% 
    x(:,i+1)=[x1n;x2n];
%
end
figure(1); plot(t,x(1,:),':g','linewidth',2); hold on; xlim([0 4]);
figure(2); plot(t,x(2,:),':g','linewidth',2); hold on; xlim([0 4]);  
%
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Strong order 1.0 Milstein scheme
%                            dt = 0.03
% ------------------------------------------------------------------------
% 
clear x dt;
dt=0.03;   % time step
t=0:dt:T;   % time variable
Nt=numel(t);
%
% initial conditions
x_init=[0.1;0.1];
x(:,1)=x_init;
for i=1:Nt-1
%  
    x1o=x(1,i);
    x2o=x(2,i);
% 
    A1 = x2o;
    A2 = 1/m*(-c*x2o-2*k*x1o+P*cos(w*(i-1)*dt));
    Bb = sig/m;
    x1n=x1o+A1*dt;
    x2n=x2o+A2*dt + Bb*sqrt(dt)*randn;
% 
    if x1n>=g
        x2n=x2n+1/m*(-cc*x2o-kc*(x1n-g))*dt;
    end
% 
    x(:,i+1)=[x1n;x2n];
%
end
figure(1); plot(t,x(1,:),'o','MarkerSize',5,'MarkerEdgeColor','red',...
    'MarkerFaceColor',[1 0.6 0.6]); hold on; xlim([0 4]);  
figure(2); plot(t,x(2,:),'o','MarkerSize',5,'MarkerEdgeColor','red',...
    'MarkerFaceColor',[1 0.6 0.6]); hold on; xlim([0 4]);
% 
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Improved solution using GCEM
%                            dt = 0.03
% ------------------------------------------------------------------------
clear x dt;
%
Np=100; % ensemble size
dt=0.03;
t=0:dt:T;
%
% initial conditions
x_init=[0.1;0.1];
X=x_init*ones(1,Np);
X_s(:,1) = mean(X,2);
for i = 1:numel(t)-1
    i   
    for j = 1:Np
        x1o=X(1,j);
        x2o=X(2,j);
% 
        x1n=x1o+x2o*dt;
        x2n=1/m*(-c*x2o-2*k*x1o+P*cos(w*(i-1)*dt));
        if x1n>=g
            x2n=x2n+1/m*(-cc*x2o-kc*(x1n-g));
        end
        b_pre(:,j)=[x2o;x2n];
        X1(:,j) = X(:,j) + b_pre(:,j)*dt + diag([0;sig])*randn(2,1);  
    end
% 
    error_norm = 1;
    it_X = 0;
    while error_norm>1e-2 && it_X<1
        it_X = it_X+1;
        for j = 1:Np
%           
            x1o=X1(1,j);
            x2o=X1(2,j);
% 
            x1n=x1o+x2o*dt;
            x2n=1/m*(-c*x2o-2*k*x1o+P*cos(w*(i-1)*dt));
            if x1o>=g
                x2n=x2n+1/m*(-cc*x2o-kc*(x1n-g));
            end
            b(:,j)=[x2o;x2n];
            e(:,j) = (b(:,j) - b_pre(:,j));
        end        
        h=(1/.075)*e; 
        for h1=1:2   
            dummy_sum=zeros(2,1);
            for j=1:Np
                dummy_sum=dummy_sum+(h(h1,j).*X1(:,j));
            end
            gain1(:,h1)=dummy_sum/Np;
            gain2(:,h1)=mean(h(h1,:))*mean(X1,2);
        end
        kushner_gain=gain1-gain2;
        G_lin=kushner_gain;
%
        for u = 1:Np
            X2(:,u) = X1(:,u) + G_lin*(0 - h(:,u)*dt);% Update
        end     
%       
    error_norm = norm(mean(X2,2) - mean(X1,2));
    X1 = X2;
    end
X = X2;
X_s(:,i+1) = mean(X,2);
end
figure(1); plot(t,X_s(1,:),'o','MarkerSize',5,'MarkerEdgeColor','blue',...
'MarkerFaceColor','blue'); xlim([0 4]);
figure(2); plot(t,X_s(2,:),'o','MarkerSize',5,'MarkerEdgeColor','blue',...
'MarkerFaceColor','blue'); xlim([0 4]);
%     
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Weak order 3.0 Ito-Taylor scheme
%                            dt = 0.05
% ------------------------------------------------------------------------
% 
clear x dt;
dt=0.05;   
t=0:dt:T;   % time variable
Nt=numel(t);
%
% initial conditions
x_init=[0.1;0.1];
x(:,1)=x_init;
for i=1:Nt-1
%     
    x1o=x(1,i);
    x2o=x(2,i);
% 
    A1 = x2o;
    A2 = 1/m*(-c*x2o-2*k*x1o+P*cos(w*(i-1)*dt));
    Bb = sig/m;
    delW = sqrt(dt)*randn;
    delZ = 0.5*(dt)^1.5*randn + 1/(2*sqrt(3))*(dt)^1.5*randn;
    L1A1 = Bb; L1A2 = Bb/m*(-c); L0A1 = A2; L0A2 = A1/m*(-k)+A2/m*(-c);
    L1L0A1 = L1A2; L1L0A2 = -k/m*L1A1-c/m*L1A2;
    L0L0A1 = L0A2; L0L0A2 = -k/m*L0A1-c/m*L0A2;
%
    x1n = x1o+A1*dt + L1A1*delZ + L0A1*(dt)^2*0.5...
             + L1L0A1*(dt)^2/6*delW + L0L0A1*(dt)^3/6;

    x2n = x2o+A2*dt + Bb*delW + L1A2*delZ...
             + L0A2*(dt)^2*0.5 + L1L0A2*(dt)^2/6*delW...
             + L0L0A2*(dt)^3/6;
% 
    if x1n>=g
        A2 = A2+1/m*(-cc*x2o-kc*(x1n-g));
        L1A1 = Bb; L0A1 = A2; 
        L1A2 = L1A2 + Bb/m*(-cc); L0A2 = L0A2 + A1/m*(-kc)+A2/m*(-cc);
        L1L0A2 = L1L0A2  -kc/m*L1A1-cc/m*L1A2;
        L0L0A2 = L0L0A2 -kc/m*L0A1-cc/m*L0A2;
        x2n = x2o+A2*dt + Bb*delW + L1A2*delZ...
             + L0A2*(dt)^2*0.5 + L1L0A2*(dt)^2/6*delW...
             + L0L0A2*(dt)^3/6;
    end
% 
    x(:,i+1)=[x1n;x2n];
%
end
figure(1); plot(t,x(1,:),'v','MarkerSize',5,'MarkerEdgeColor','k',...
    'MarkerFaceColor','k'); hold on; xlim([0 4]);
figure(2); plot(t,x(2,:),'v','MarkerSize',5,'MarkerEdgeColor','k',...
    'MarkerFaceColor','k'); hold on; xlim([0 4]);
% 