% Fig 16: Response of the nonsmooth oscillator with non-linear SMA support
% 
%          Nonsmooth oscillator with non-linear SMA support
% 
% The analysis done for EM, Milstein and Weak 3.0 scheme
% The results are compared using dt=0.03 against a reference solution
% obtained by EM: dt=0.0001
% 
% Author: Tapas Tripura, Ankush Gogoi, Budhaditya Hazra
% Indian Institute of Technology Guwahati, Assam, India
% 
% ************************************************************************
% 
clc
clear
close all
% 
w=2*pi; c1=6; k1=100; m=1; g=0.0045; ks=0.16*k1;
xa = 0.005; xb = 0.02; lambda = 0.05;
sig=0.01; P=4;  
%
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Order 0.5 Euler-Maruyama scheme
%                            dt = 0.0001
%                       Reference solution
% ------------------------------------------------------------------------
% 
dt=0.0001;  
T=10;            % total time of integration
t=0:dt:T;   % time variable
Nt=numel(t);
%
% initial conditions
x_init=[0.1;0.1];
x(:,1)=x_init;
for i=1:Nt-1
%  
    x1o=x(1,i);
    x2o=x(2,i);
%
    A1 = x2o;
    A2 = (1/m)*(-c1*x2o-(2*k1)*x1o+P*cos(w*(i-1)*dt));
    Bb = sig/m;
    x1n=x1o+A1*dt;
    x2n=x2o+A2*dt + Bb*sqrt(dt)*randn;
% 
    if x1n>=g
        x2n=x2n + (1/m)*(-lambda*ks*(x1o-g)-(1-lambda)*ks*(x1o-g)*(1-sign(sign(abs(x1o-g)-xa)+1))...
                -(1-lambda)*ks*0.5*(sign(abs(x1o-g)-xa)+1)*((xb-xa)*0.5*(sign(x1o-g)+sign(x2o))+xa*sign(x1o-g)))*dt; 
    end
% 
    x(:,i+1)=[x1n;x2n];
%
end
figure(1); plot(t,x(1,:),'r','linewidth',2); hold on;    
figure(2); plot(t,x(2,:),'r','linewidth',2); hold on; 
%
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Order 0.5 Euler-Maruyama scheme
%                            dt = 0.03
% ------------------------------------------------------------------------
clear x
dt=0.03; 
t=0:dt:T;   % time variable
Nt=numel(t);
%
% initial conditions
x_init=[0.1;0.1];
x(:,1)=x_init;
for i=1:Nt-1
%  
    x1o=x(1,i);
    x2o=x(2,i);
%
    A1 = x2o;
    A2 = (1/m)*(-c1*x2o-(2*k1)*x1o+P*cos(w*(i-1)*dt));
    Bb = sig/m;
    x1n=x1o+A1*dt;
    x2n=x2o+A2*dt + Bb*sqrt(dt)*randn;
%
    if x1n>=g
        x2n=x2n + (1/m)*(-lambda*ks*(x1o-g)-(1-lambda)*ks*(x1o-g)*(1-sign(sign(abs(x1o-g)-xa)+1))...
                -(1-lambda)*ks*0.5*(sign(abs(x1o-g)-xa)+1)*((xb-xa)*0.5*(sign(x1o-g)+sign(x2o))+xa*sign(x1o-g)))*dt;
    end
% 
    x(:,i+1)=[x1n;x2n];
%
end
figure(1); plot(t,x(1,:),':g','linewidth',2); hold on; xlim([0 4]);
figure(2); plot(t,x(2,:),':g','linewidth',2); hold on; xlim([0 4]); 
%
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Strong order 1.0 Milstein scheme
%                            dt = 0.03
% ------------------------------------------------------------------------
% 
clear x
dt=0.03; 
t=0:dt:T;   % time variable
Nt=numel(t);
%
% initial conditions
x_init=[0.1;0.1];
x(:,1)=x_init;
for i=1:Nt-1
    x1o=x(1,i);
    x2o=x(2,i);
% 
    A1 = x2o;
    A2 = 1/m*(-c1*x2o-(2*k1)*x1o+P*cos(w*(i-1)*dt));
    Bb = sig/m;
    x1n=x1o+A1*dt;
    x2n=x2o+A2*dt + Bb*sqrt(dt)*randn;
% 
    if x1n>=g
        x2n=x2n + (1/m)*(-lambda*ks*(x1o-g)-(1-lambda)*ks*(x1o-g)*(1-sign(sign(abs(x1o-g)-xa)+1))...
                -(1-lambda)*ks*0.5*(sign(abs(x1o-g)-xa)+1)*((xb-xa)*0.5*(sign(x1o-g)+sign(x2o))+xa*sign(x1o-g)))*dt;
    end
% 
    x(:,i+1)=[x1n;x2n];
%
end
figure(1); plot(t,x(1,:),'o','MarkerSize',5,'MarkerEdgeColor','red',...
    'MarkerFaceColor',[1 0.6 0.6]); hold on; xlim([0 4]);  
figure(2); plot(t,x(2,:),'o','MarkerSize',5,'MarkerEdgeColor','red',...
    'MarkerFaceColor',[1 0.6 0.6]); hold on; xlim([0 4]);
% 
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Improved solution using GCEM
%                            dt = 0.03
% ------------------------------------------------------------------------
%
Np=100; % ensemble size
dt=0.03;
t=0:dt:T;
%
% initial conditions
x_init=[0.1;0.1];
X=x_init*ones(1,Np);
%
X_s(:,1) = mean(X,2);
for i = 1:numel(t)-1
    i   % time step counter
    for j = 1:Np
%   
        x1o=X(1,j);
        x2o=X(2,j);
%
        A1 = x2o;
        A2 = (1/m)*(-c1*x2o-(2*k1)*x1o+P*cos(w*(i-1)*dt));
        x1n=x1o+A1*dt;
        x2n=A2;
        if x1n>=g
            x2n=x2n+(1/m)*(-lambda*ks*(x1o-g) ...
                -(1-lambda)*ks*(x1o-g)*(1-sign(sign(abs(x1o-g)-xa)+1))...
                    -(1-lambda)*ks*0.5*(sign(abs(x1o-g)-xa)+1) ...
                    *((xb-xa)*0.5*(sign(x1o-g)+sign(x2o))+xa*sign(x1o-g)));
%  
        end
            b_pre(:,j)=[x2o;x2n];
            X1(:,j) = X(:,j) + b_pre(:,j)*dt + diag([0;sig])*randn(2,1);  % prediction
    end
% 
    error_norm = 1;
    it_X = 0;
    while error_norm>1e-4 && it_X<2
        it_X = it_X+1;
        for j = 1:Np
%   
        x1o=X1(1,j); 
        x2o=X1(2,j);
        %
        A1 = x2o;
        A2 = (1/m)*(-c1*x2o-(2*k1)*x1o+P*cos(w*(i-1)*dt));
        x1n=x1o+A1*dt;
        x2n=A2;
        if x1o>=g
            x2n=x2n+(1/m)*(-lambda*ks*(x1n-g) ...
            -(1-lambda)*ks*(x1n-g)*(1-sign(sign(abs(x1n-g)-xa)+1))...
                    -(1-lambda)*ks*0.5*(sign(abs(x1n-g)-xa)+1) ...
                    *((xb-xa)*0.5*(sign(x1n-g)+sign(x2o))+xa*sign(x1n-g)));
        end
% 
            b(:,j)=[x2o;x2n];
            e(:,j) = (b(:,j) - b_pre(:,j));
        end        
            h=(1/.077)*e; 
            for h1=1:2   
                dummy_sum=zeros(2,1);
                for j=1:Np
                    dummy_sum=dummy_sum+(h(h1,j).*X1(:,j));
                end
                gain1(:,h1)=dummy_sum/Np;
                gain2(:,h1)=mean(h(h1,:))*mean(X1,2);
            end
            kushner_gain=gain1-gain2;
            G_lin=kushner_gain;
 %
            for u = 1:Np
                X2(:,u) = X1(:,u) + G_lin*(0 - h(:,u)*dt);% Update
            end     
        %       
        error_norm = norm(mean(X2,2) - mean(X1,2));
        X1 = X2;
    end
    X = X2;
    X_s(:,i+1) = mean(X,2);
end
figure(1); plot(t,X_s(1,:),'o','MarkerSize',5,'MarkerEdgeColor','blue',...
'MarkerFaceColor','blue'); xlim([0 4]);
figure(2); plot(t,X_s(2,:),'o','MarkerSize',5,'MarkerEdgeColor','blue',...
'MarkerFaceColor','blue'); xlim([0 4]);
%     
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Weak order 3.0 Ito-Taylor scheme
%                            dt = 0.05
% ------------------------------------------------------------------------
% 
clear x;
dt=0.03;   % time step
T=10;            % total time of integration
t=0:dt:T;   % time variable
Nt=numel(t);
%
% initial conditions
x_init=[0.1;0.1];
x(:,1)=x_init;
for i=1:Nt-1
%     
    x1o=x(1,i);
    x2o=x(2,i);
% 
    A1 = x2o;
    A2 = 1/m*(-c1*x2o-(2*k1)*x1o+P*cos(w*(i-1)*dt));
    Bb = sig/m;
    delW = sqrt(dt)*randn;
    delZ = 0.5*(dt)^1.5*randn + 1/(2*sqrt(3))*(dt)^1.5*randn;
    L1A1 = Bb; L1A2 = Bb/m*(-c1); L0A1 = A2; L0A2 = A1/m*(-(2*k1))+A2/m*(-c1);
    L1L0A1 = L1A2; L1L0A2 = -((2*k1)/m)*L1A1-(c1/m)*L1A2;
    L0L0A1 = L0A2; L0L0A2 = -((2*k1)/m)*L0A1-(c1/m)*L0A2;
%
    x1n = x1o+A1*dt + L1A1*delZ + L0A1*(dt)^2*0.5...
             + L1L0A1*(dt)^2/6*delW + L0L0A1*(dt)^3/6;

    x2n = x2o+A2*dt + Bb*delW + L1A2*delZ...
             + L0A2*(dt)^2*0.5 + L1L0A2*(dt)^2/6*delW...
             + L0L0A2*(dt)^3/6;
% 
    if x1n>=g
        A2 = A2+(1/m)*(-lambda*ks*(x1o-g)-(1-lambda)*ks*(x1o-g)*(1-sign(sign(abs(x1o-g)-xa)+1))...
                -(1-lambda)*ks*0.5*(sign(abs(x1o-g)-xa)+1)*((xb-xa)*0.5*(sign(x1o-g)+sign(x2o))+xa*sign(x1o-g)))*dt;
        L1A1 = Bb; 
% 
        L1A2 = L1A2 - Bb/m*(1-lambda)*ks*(xb-xa)*0.5*(sign(abs(x1o-g)-xa)+1)*diracdelta(x2o);
        L0A2 = L0A2 + A2/m*(-(1-lambda)*ks*(xb-xa)*0.5*(sign(abs(x1o-g)-xa)+1)*diracdelta(x2o))...
               + A1/m*(-lambda*ks-(1-lambda)*ks*(1-sign(sign(abs(x1o-g)-xa)+1))-(1-lambda)*ks*(x1o-g)*(-4*diracdelta(sign(abs(x1o-g)-xa)+1)*diracdelta(abs(x1o-g)-xa)*sign(x1o-g))...
               -(1-lambda)*ks*diracdelta(abs(x1o-g)-xa)*sign(x1o-g)*((xb-xa)*0.5*(sign(x1o-g)+sign(x2o))+xa*sign(x1o-g))...
               -(1-lambda)*ks*0.5*(sign(abs(x1o-g)-xa)+1)*(xb+xa)*diracdelta(x1o-g)...
               +0.5*Bb^2*((1-lambda)*ks*0.5*(sign(abs(x1o-g)-xa)+1)*(xb+xa)*diracdelta(x2o)/x2o));
        L0L1A2 = -Bb/m*(1-lambda)*ks*(xb-xa)*(A1*diracdelta(abs(x1o-g)-xa)*sign(x1o-g)*diracdelta(x2o)...
                  -A2*0.5*(sign(abs(x1o-g)-xa)+1)*diracdelta(x2o)/x2o - Bb^2*0.5*(sign(abs(x1o-g)-xa)+1)*diracdelta(x2o)/(x2o)^2);
% 
        L1L0A2 = L1L0A2 +1/m*L1A2*(-(1-lambda)*ks*(xb-xa)*0.5*(sign(abs(x1o-g)-xa)+1)*diracdelta(x2o))...
                  + A2/m*(1-lambda)*ks*(xb-xa)*0.5*(sign(abs(x1o-g)-xa)+1)*diracdelta(x2o)/x2o*Bb...
                  +L1A1/m*(-lambda*ks-(1-lambda)*ks*(1-sign(sign(abs(x1o-g)-xa)+1))-(1-lambda)*ks*(x1o-g)*(-4*diracdelta(sign(abs(x1o-g)-xa)+1)*diracdelta(abs(x1o-g)-xa)*sign(x1o-g))...
               -(1-lambda)*ks*diracdelta(abs(x1o-g)-xa)*sign(x1o-g)*((xb-xa)*0.5*(sign(x1o-g)+sign(x2o))+xa*sign(x1o-g))...
               -(1-lambda)*ks*0.5*(sign(abs(x1o-g)-xa)+1)*(xb+xa)*diracdelta(x1o-g)...
               +0.5*Bb^2*((1-lambda)*ks*0.5*(sign(abs(x1o-g)-xa)+1)*(xb+xa)*diracdelta(x2o)/x2o))...
               +A1/m*(-(1-lambda)*ks*(xb-xa)*diracdelta(abs(x1o-g)-xa)*sign(x1o-g)*diracdelta(x2o)*Bb...
               -Bb^3*(1-lambda)*ks*(xb-xa)*0.5*(sign(abs(x1o-g)-xa)+1)*diracdelta(x2o)/(x2o)^2);
        L1L1A2 = Bb^2/m*(1-lambda)*ks*(xb-xa)*0.5*(sign(abs(x1o-g)-xa)+1)*diracdelta(x2o)/(x2o);
% 
        L0L0A2 = L0L0A2 + L0A2/m*(-(1-lambda)*ks*(xb-xa)*0.5*(sign(abs(x1o-g)-xa)+1)*diracdelta(x2o))...
                 - (1-lambda)*ks*(xb-xa)*A2/m*(A1*diracdelta(abs(x1o-g)-xa)*sign(x1o-g)*diracdelta(x2o)...
                 - A2*0.5*(sign(abs(x1o-g)-xa)+1)*diracdelta(x2o)/(x2o) + 0.5*Bb^2*(sign(abs(x1o-g)-xa)+1)*diracdelta(x2o)/(x2o)^2)...
                 +L0A1/m*(-lambda*ks-(1-lambda)*ks*(1-sign(sign(abs(x1o-g)-xa)+1))-(1-lambda)*ks*(x1o-g)*(-4*diracdelta(sign(abs(x1o-g)-xa)+1)*diracdelta(abs(x1o-g)-xa)*sign(x1o-g))...
               -(1-lambda)*ks*diracdelta(abs(x1o-g)-xa)*sign(x1o-g)*((xb-xa)*0.5*(sign(x1o-g)+sign(x2o))+xa*sign(x1o-g))...
               -(1-lambda)*ks*0.5*(sign(abs(x1o-g)-xa)+1)*(xb+xa)*diracdelta(x1o-g)...
               +0.5*Bb^2*((1-lambda)*ks*0.5*(sign(abs(x1o-g)-xa)+1)*(xb+xa)*diracdelta(x2o)/x2o))...
               + (A1)^2/m*(-(1-lambda)*ks*(x1o-g)*(-4*diracdelta(sign(abs(x1o-g)-xa)+1)*diracdelta(abs(x1o-g)-xa)*sign(x1o-g)));
        x2n = x2o+A2*dt + Bb*delW + L1A2*delZ...
             + L0A2*(dt)^2*0.5 + (L0L1A2+L1L0A2)*(dt)^2/6*delW...
             + L1L1A2*dt/6*((delW)^2-dt)...
             + L0L0A2*(dt)^3/6;
%    
    end
% 
    x(:,i+1)=[x1n;x2n];
%
end
figure(1); plot(t,x(1,:),'v','MarkerSize',5,'MarkerEdgeColor','k',...
    'MarkerFaceColor','k'); hold on; xlim([0 4]);
figure(2); plot(t,x(2,:),'v','MarkerSize',5,'MarkerEdgeColor','k',...
    'MarkerFaceColor','k'); hold on; xlim([0 4]);
% 
% 