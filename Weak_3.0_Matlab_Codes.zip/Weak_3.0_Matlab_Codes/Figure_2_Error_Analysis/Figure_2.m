%   Fig 2: Log absolute error v/s log dt
% 
%                   Error analysis/Order of convergence
% 
% The analysis done for EM, Milstein and Weak 3.0 scheme
% Black-Scholes SDEs is utilised for the analysis due to its availability
% of true solution
% 
% Author: Tapas Tripura, Ankush Gogoi, Budhaditya Hazra
% Indian Institute of Technology Guwahati, Assam, India
% 
% ***********************************************************************
%
clc
clear
close all 
%
T=1;    % total time of integration
N=2000;   % no. of ensemble in each independent MC run 
Nsamp=100;   % no. of independent MC runs
%
% Black-Scholes SDE 
  lambda=2.0; 
  mu=0.01;  %   
  cnst=lambda-(mu^2)/2.0;
% 
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Order 0.5 Euler-Maruyama Scheme
%                            
% ------------------------------------------------------------------------
%
% initial condition
x0=1.0;
% 
% initialization of the variable indocating global error
 for i=1:7
   errm(i)=0.0;
 end
% 
%  start of MC runs
for MC=1:Nsamp
    MC    % MC counter
%
for i=1:7   % integration with 5 different time steps
%
    if(i==1); dt=0.25*2^-6;
    elseif(i==2); dt=2*2^-6;
    elseif(i==3); dt=4*2^-6;
    elseif(i==4); dt=8*2^-6;
    elseif(i==5); dt=16*2^-6;
    elseif(i==6); dt=32*2^-6;
    elseif(i==7); dt=64*2^-6;
    end
%
t=0:dt:T;   % time variable
Nt=numel(t);
%
xtr=0.0;   % initializaton for true solution variable
xsMSI=0.0;  % initializaton for the solution variable of higher order scheme
                                        % with MSIs
% 
for j=1:N
dW(1)=sqrt(dt)*randn;
B(1)=dW(1);
xtrue(1)=x0*exp(cnst*t(1)+mu*B(1));    % true solution at t(1)
%
xo(1)=x0;
%
for k=2:numel(t)
%
    dW1(k)=sqrt(dt)*randn;
    dW2(k)=sqrt(dt)*randn;
    dW(k)=sqrt(dt)*randn;
%   
    Iw=dW(k);
    Iws=0.5*dt*(dW1(k)+dW2(k)/sqrt(3));
    Isw=0.5*dt*(dW1(k)-dW2(k)/sqrt(3));
    Iww=0.5*(Iw*Iw-dt);
    Iwww=(1/6.0)*(Iw*Iw-3*dt)*Iw;
    Iwss=1/6*Iw*dt^2;
    Isww = 1/6*(Iw*Iw-dt)*dt;
    Isss=1/6*dt^3;
%
    B(k) = B(k-1) + dW(k);
    xtrue(k)=x0*exp(cnst*t(k)+mu*B(k));   % true solution at t(k)
%
    xn(k)=xo(k-1) + lambda*xo(k-1)*dt + mu*xo(k-1)*dW(k);  
% 
    xo(k)=xn(k);
%
end          %  end of time integration 
%
    xtr(j)=max(xtrue);   % max of true solution 
    xsMSI(j)=max(xn);  
    xerr(i,j)=(xtr(j)-xsMSI(j))^2;  
%
end      
%
end            
%
for i=1:7
%  
    if(i==1);  dt=0.25*2^-6;
    elseif(i==2); dt=2*2^-6;
    elseif(i==3); dt=4*2^-6;
    elseif(i==4); dt=8*2^-6;
    elseif(i==5); dt=16*2^-6;
    elseif(i==6); dt=32*2^-6;
    elseif(i==7); dt=64*2^-6;
    end
% 
sum=0.0;
%
for j=1:N
sum=sum+xerr(i,j);
end
%
errx(i)=sqrt(sum/N);  % average over N samples 
errm(i)=errm(i)+errx(i)/Nsamp;  % average over NMC number of MC runs 
xdt(i)=log2(dt);  % logarithm of time step wrt the base '2'
% 
end
%
end               % end of NMC independent MC runs
%
for i=1:7
    errm(i)=log2(errm(i));  % logarithm of error wrt the base '2'
end
%
figure(1); plot(xdt,errm,'-ok'); hold on;
%
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Strong order 1.0 Milstein scheme
%                            
% -----------------------------------------------------------------------
%
% initial condition
x0=1.0;
% 
% initialization of the variable indocating global error
 for i=1:7
   errm(i)=0.0;
 end
% 
%  start of MC runs
for MC=1:Nsamp
    MC    % MC counter
%
for i=1:7   % integration with 5 different time steps
%
    if(i==1); dt=0.25*2^-6;
    elseif(i==2); dt=2*2^-6;
    elseif(i==3); dt=4*2^-6;
    elseif(i==4); dt=8*2^-6;
    elseif(i==5); dt=16*2^-6;
    elseif(i==6); dt=32*2^-6;
    elseif(i==7); dt=64*2^-6;
    end
%
t=0:dt:T;   % time variable
Nt=numel(t);
%
xtr=0.0;   % initializaton for true solution variable
xsMSI=0.0;  % initializaton for the solution variable of higher order scheme
                                        % with MSIs
% 
for j=1:N
dW(1)=sqrt(dt)*randn;
B(1)=dW(1);
xtrue(1)=x0*exp(cnst*t(1)+mu*B(1));    % true solution at t(1)
%
xo(1)=x0;
%
for k=2:numel(t)
%
    dW1(k)=sqrt(dt)*randn;
    dW2(k)=sqrt(dt)*randn;
    dW(k)=sqrt(dt)*randn;
%   
    Iw=dW(k);
    Iws=0.5*dt*(dW1(k)+dW2(k)/sqrt(3));
    Isw=0.5*dt*(dW1(k)-dW2(k)/sqrt(3));
    Iww=0.5*(Iw*Iw-dt);
    Iwww=(1/6.0)*(Iw*Iw-3*dt)*Iw;
    Iwss=1/6*Iw*dt^2;
    Isww = 1/6*(Iw*Iw-dt)*dt;
    Isss=1/6*dt^3;
%
    B(k) = B(k-1) + dW(k);
    xtrue(k)=x0*exp(cnst*t(k)+mu*B(k));   % true solution at t(k)
%
    xn(k)=xo(k-1) + lambda*xo(k-1)*dt + mu*xo(k-1)*dW(k)...
            + mu*mu*xo(k-1)*Iww;
% 
    xo(k)=xn(k);
%
end          %  end of time integration 
%
    xtr(j)=max(xtrue);   % max of true solution 
    xsMSI(j)=max(xn);  
    xerr(i,j)=(xtr(j)-xsMSI(j))^2;  
%
end      
%
end            
%
for i=1:7
%  
    if(i==1);  dt=0.25*2^-6;
    elseif(i==2); dt=2*2^-6;
    elseif(i==3); dt=4*2^-6;
    elseif(i==4); dt=8*2^-6;
    elseif(i==5); dt=16*2^-6;
    elseif(i==6); dt=32*2^-6;
    elseif(i==7); dt=64*2^-6;
    end
% 
sum=0.0;
%
for j=1:N
sum=sum+xerr(i,j);
end
%
errx(i)=sqrt(sum/N);  % average over N samples 
errm(i)=errm(i)+errx(i)/Nsamp;  % average over NMC number of MC runs 
xdt(i)=log2(dt);  % logarithm of time step wrt the base '2'
% 
end
%
end               % end of NMC independent MC runs
%
for i=1:7
    errm(i)=log2(errm(i));  % logarithm of error wrt the base '2'
end
%
figure(1); plot(xdt,errm,'-ob'); hold on;   
%
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Weak order 3.0 Ito-Taylor scheme
%                           
% -----------------------------------------------------------------------
%
% initial condition
x0=1.0;
% 
% initialization of the variable indocating global error
 for i=1:7
   errm(i)=0.0;
 end
% 
%  start of MC runs
for MC=1:Nsamp
    MC    % MC counter
%
for i=1:7   % integration with 5 different time steps
%
    if(i==1); dt=0.25*2^-6;
    elseif(i==2); dt=2*2^-6;
    elseif(i==3); dt=4*2^-6;
    elseif(i==4); dt=8*2^-6;
    elseif(i==5); dt=16*2^-6;
    elseif(i==6); dt=32*2^-6;
    elseif(i==7); dt=64*2^-6;
    end
%
t=0:dt:T;   % time variable
Nt=numel(t);
%
xtr=0.0;   % initializaton for true solution variable
xsMSI=0.0;  % initializaton for the solution variable of higher order scheme
                                        % with MSIs
% 
for j=1:N
dW(1)=sqrt(dt)*randn;
B(1)=dW(1);
xtrue(1)=x0*exp(cnst*t(1)+mu*B(1));    % true solution at t(1)
%
xo(1)=x0;
%
for k=2:numel(t)
%
    dW1(k)=sqrt(dt)*randn;
    dW2(k)=sqrt(dt)*randn;
    dW(k)=sqrt(dt)*randn;
%   
    Iw=dW(k);
    Iws=0.5*dt*(dW1(k)+dW2(k)/sqrt(3));
    Isw=0.5*dt*(dW1(k)-dW2(k)/sqrt(3));
    Iww=0.5*(Iw*Iw-dt);
    Iwww=(1/6.0)*(Iw*Iw-3*dt)*Iw;
    Iwss=1/6*Iw*dt^2;
    Isww = 1/6*(Iw*Iw-dt)*dt;
    Isss=1/6*dt^3;
%
    B(k) = B(k-1) + dW(k);
    xtrue(k)=x0*exp(cnst*t(k)+mu*B(k));   % true solution at t(k)
% 
    xn(k) = xo(k-1) + lambda*xo(k-1)*dt + mu*xo(k-1)*dW(k)...
          + mu^2*xo(k-1)*Iww + mu*lambda*xo(k-1)*Iws...
          + lambda^2*xo(k-1)*0.5*dt^2 + mu*lambda*xo(k-1)*Isw...
          + 3*mu*lambda^2*xo(k-1)*Iwss + mu^2*lambda*xo(k-1)*Isww...
          + lambda^3*xo(k-1)*Isss + mu^3*xo(k-1)*Iwww;
% 
    xo(k)=xn(k);
%
end          %  end of time integration 
%
    xtr(j)=max(xtrue);   % max of true solution 
    xsMSI(j)=max(xn);  
    xerr(i,j)=(xtr(j)-xsMSI(j))^2;  
%
end      
%
end            
%
for i=1:7
%  
    if(i==1);  dt=0.25*2^-6;
    elseif(i==2); dt=2*2^-6;
    elseif(i==3); dt=4*2^-6;
    elseif(i==4); dt=8*2^-6;
    elseif(i==5); dt=16*2^-6;
    elseif(i==6); dt=32*2^-6;
    elseif(i==7); dt=64*2^-6;
    end
% 
sum=0.0;
%
for j=1:N
sum=sum+xerr(i,j);
end
%
errx(i)=sqrt(sum/N);  % average over N samples 
errm(i)=errm(i)+errx(i)/Nsamp;  % average over NMC number of MC runs 
xdt(i)=log2(dt);  % logarithm of time step wrt the base '2'
% 
end
%
end               % end of NMC independent MC runs
%
for i=1:7
    errm(i)=log2(errm(i));  % logarithm of error wrt the base '2'
end
%
figure(1); plot(xdt,errm,'-or'); hold on; 
xlabel('log_2 (\Delta t)'); ylabel('log_2 |\epsilon|');
legend('EM','Milstein','Weak 3.0','location','southeast');
%
