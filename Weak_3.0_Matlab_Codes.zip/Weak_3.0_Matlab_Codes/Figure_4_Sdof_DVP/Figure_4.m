%   Fig. 4 Displacement of the SDOF Duffing Van der pol system using order
%   3.0 weak Taylor and Milstein scheme
% 
%            Sdof Duffing-Van der pol oscillator SDOF under sine+WGN
% 
%   Higher order scheme (Weak Taylor 3.0 scheme) by Ito-Taylor eYpansion 
%  Comparison with Milstein scheme
% 
% Author: Tapas Tripura, Ankush Gogoi, Budhaditya Hazra
% Indian Institute of Technology Guwahati, Assam, India
% 
% ***********************************************************************
clc
clear 
close all
% 
T=20;    
N=100;   % no. of samples in the MC run
%
% Parameters of the Duffing-Van der Pol oscillator ::
sigma =1;    
k1 =600;
m1 = 15; alpha = 20; c1 = 2;
%
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Strong order 1.0 Milstein scheme
%                            dt = 0.0001
% -----------------------------------------------------------------------
dt=0.0001; 
t=0:dt:T;
for MC=1:N
    MC % sample counter
    
    omega = 5; % hertz
    Signal = 0.1*sin(2*pi*10*t);  % single period stable, 
% 
    Y= zeros(numel(t),1);
    dY= zeros(numel(t),1); 
% 
    Y1o= 0.001;
    Y2o= 0;
    Y(1)= 0.001; 
    dY(1)= 0;
%
% start of integration ::
for n=1:numel(t)-1
%
    dW1=sqrt(dt)*randn;
    dW2=sqrt(dt)*randn;
    dW=sqrt(dt)*randn;
%
    Iws=0.5*dt*(dW1+dW2/sqrt(3));
    Isw=0.5*dt*(dW1-dW2/sqrt(3));
    Iss=0.5*dt*dt;
%  
    A1=Y2o;
    A2=Y1o*(k1/m1-alpha*Y1o^2/m1)-c1*Y2o/m1;
%        
    Y1n= Y1o + A1*dt; 
    Y2n= Y2o + A2*dt + sigma/m1*Y1o*dW + Signal(n)*dt;  % Milstein
%
    dY(n+1)=Y2n;
    Y(n+1)=Y1n;
%    
    Y1o= Y(n+1);
    Y2o= dY(n+1);
end
%
Y1(MC,:) = Y;
Y2(MC,:) = dY;
% 
end
% 
u = mean(Y1);
udot = mean(Y2);
% 
figure(1), plot(t,u,'--r','linewidth',2); hold on;
clear u udot Y1 Y2;
% 
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Strong order 1.0 Milstein scheme
%                            dt = 0.002
% -----------------------------------------------------------------------
dt=0.002; 
t=0:dt:T;
%
for MC=1:N
    MC % sample counter
    
    omega = 5; % hertz
    Signal = 0.1*sin(2*pi*10*t);  % single period stable, 
% 
    Y= zeros(numel(t),1);
    dY= zeros(numel(t),1); 
% 
    Y1o= 0.001;
    Y2o= 0;
    Y(1)= 0.001; 
    dY(1)= 0;
%
% start of integration ::
for n=1:numel(t)-1
%
    dW1=sqrt(dt)*randn;
    dW2=sqrt(dt)*randn;
    dW=sqrt(dt)*randn;
%
    Iws=0.5*dt*(dW1+dW2/sqrt(3));
    Isw=0.5*dt*(dW1-dW2/sqrt(3));
    Iss=0.5*dt*dt;
%  
    A1=Y2o;
    A2=Y1o*(k1/m1-alpha*Y1o^2/m1)-c1*Y2o/m1;
%        
    Y1n= Y1o + A1*dt; 
    Y2n= Y2o + A2*dt + sigma/m1*Y1o*dW + Signal(n)*dt;  % Milstein
%
    dY(n+1)=Y2n;
    Y(n+1)=Y1n;
%    
    Y1o= Y(n+1);
    Y2o= dY(n+1);
end
%
Y1(MC,:) = Y;
Y2(MC,:) = dY;
% 
end 
% 
u = mean(Y1);
udot = mean(Y2);
% 
figure(1), plot(t,u,'m','linewidth',2); hold on;
clear u udot Y1 Y2;
% 
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Weak order 3.0 Ito-Taylor scheme
%                               dt=0.01
% -----------------------------------------------------------------------
dt=0.01;
t=0:dt:T;
%
for MC=1:N
    MC % sample counter
    
    SNR = 10;
    omega = 5; % hertz
    Signal = 0.1*sin(2*pi*10*t);  % single period stable,

    Y= zeros(numel(t),1);
    dY= zeros(numel(t),1); 
% 
    Y1o= 0.001;
    Y2o= 0;
    Y(1)= 0.001; 
    dY(1)= 0;
%
% start of integration ::
for n=1:numel(t)-1
%
    dW1=sqrt(dt)*randn;
    dW2=sqrt(dt)*randn;
    dW=sqrt(dt)*randn;
%
    Iws=0.5*dt*(dW1+dW2/sqrt(3));
    Isw=0.5*dt*(dW1-dW2/sqrt(3));
    Iss=0.5*dt*dt;
%  
    A1=Y2o;
    A2=Y1o*(k1/m1-alpha*Y1o^2/m1)-c1*Y2o/m1;
%     
    Y1n= Y1o + A1*dt + sigma/m1*Y1o*Iws + A2*Iss ...             % Taylor weak 3.0
           + sigma/m1*(A1 - Y1o*c1/m1)*(1/6)*dt*dt*dW ...
           + (A1*(k1/m1-3*Y1o*Y1o*alpha/m1)-A2*c1/m1)*dt*dt*dt/6;
%    
    Y2n= Y2o + A2*dt + sigma/m1*Y1o*dW + Signal(n)*dt - sigma*Y1o*c1/(m1)^2*Iws ...
          + sigma/m1*Y2o*Isw + (A1*(k1/m1-3*Y1o*Y1o*alpha/m1)-A2*c1/m1)*Iss ...
          + sigma*(-Y2o*c1/(m1)^2 + Y1o/m1*(k1/m1-3*Y1o*Y1o*alpha/m1+(c1/m1)^2)+A2/m1)*dW*dt*dt/6 ...
          + (sigma/m1)^2*Y1o*(dW*dW-dt)*dt/6 ...
          + (A1*(3*Y1o*Y1o*c1*alpha/(m1)^2-6*Y1o*Y2o*alpha/m1-k1*c1/(m1)^2)+A2*(k1/m1+(c1/m1)^2 ...
            -3*Y1o*Y1o*alpha/m1))*dt*dt*dt/6; 
% 
    dY(n+1)=Y2n;
    Y(n+1)=Y1n;
%    
    Y1o= Y(n+1);
    Y2o= dY(n+1);
end
%
Y1(MC,:) = Y;
Y2(MC,:) = dY;
% 
end
% 
u = mean(Y1);
udot = mean(Y2);
% 
figure(1), plot(t,u,'k','linewidth',2); hold on;
xlabel('Time (s)'); ylabel('E[X] (m)');
legend('Milstein (\Delta t=0.0001s)','Milstein (\Delta t=0.002s)','Weak 3.0 (\Delta t=0.01s)');
% 