%   Figure 5: Phase space diagram for SDOF Duffing�Vanderpol System with 
%   varying parameters of harmonic excitation
% 
%            Sdof Duffing-Van der pol oscillator SDOF under sine+WGN
% 
%   Stability study using Higher order scheme (Weak Taylor 3.0 scheme)  
%  for the sdof Duffing-Van der pol oscillator
% 
% Author: Tapas Tripura, Ankush Gogoi, Budhaditya Hazra
% Indian Institute of Technology Guwahati, Assam, India
% 
% ***********************************************************************
% 
clc
clear 
close all
%
% Time parameters ::
T=20;    
dt=0.01;
t=0:dt:T;
Nlast=numel(t);
N=100;   % no. of samples in the MC run
%
% Parameters of the Duffing-Van der Pol oscillator ::
sigma =0.1;   
k1 =600;
m1 = 15; alpha = 20; c1 = 2;
%
%
for i=1:8
    i
    if i==1
        Signal = 10*sin(2*pi*0.5*t);  % Fig. 5 (a)
    elseif i==2
        Signal = 7*sin(2*pi*0.5*t);  % Fig. 5 (b)
    elseif i==3
        Signal = 4*sin(2*pi*0.5*t); % Fig. 5 (c)
    elseif i==4
        Signal = 0.5*sin(2*pi*0.5*t);  % Fig. 5 (d)
    elseif i==5
        Signal = 10*sin(2*pi*0.01*t); % Fig. 5 (e)
    elseif i==6
        Signal = 10*sin(2*pi*1*t);  % Fig. 5 (f)
    elseif i==7
        Signal = 10*sin(2*pi*3.0*t);  % Fig. 5 (g)
    elseif i==8
        Signal = 10*sin(2*pi*20*t);  % Fig. 5 (h)
    end
% 
for MC=1:N
    MC; % sample counter
%     
    SNR = 10;
    omega = 5; % hertz

    y= zeros(numel(t),1);
    dy= zeros(numel(t),1); 
% 
    y1o= 0.001;
    y2o= 0;
    y(1)= 0.001; 
    dy(1)= 0;
%
% start of integration ::
for n=1:numel(t)-1
%
    db1=sqrt(dt)*randn;
    db2=sqrt(dt)*randn;
    db=sqrt(dt)*randn;
%
    I10=0.5*dt*(db1+db2/sqrt(3));
    I01=0.5*dt*(db1-db2/sqrt(3));
    I00=0.5*dt*dt;
%  
    A1=y2o;
    A2=y1o*(k1/m1-alpha*y1o^2/m1)-c1*y2o/m1;
%
    y1n= y1o + A1*dt + sigma/m1*y1o*I10 + A2*I00 ...             % Taylor weak 3.0
           + sigma/m1*(A1 - y1o*c1/m1)*(1/6)*dt*dt*db ...
           + (A1*(k1/m1-3*y1o*y1o*alpha/m1)-A2*c1/m1)*dt*dt*dt/6;
%    
    y2n= y2o + A2*dt + sigma/m1*y1o*db + Signal(n)*dt - sigma*y1o*c1/(m1)^2*I10 ...
          + sigma/m1*y2o*I01 + (A1*(k1/m1-3*y1o*y1o*alpha/m1)-A2*c1/m1)*I00 ...
          + sigma*(-y2o*c1/(m1)^2 + y1o/m1*(k1/m1-3*y1o*y1o*alpha/m1+(c1/m1)^2)+A2/m1)*db*dt*dt/6 ...
          + (sigma/m1)^2*y1o*(db*db-dt)*dt/6 ...
          + (A1*(3*y1o*y1o*c1*alpha/(m1)^2-6*y1o*y2o*alpha/m1-k1*c1/(m1)^2)+A2*(k1/m1+(c1/m1)^2-3*y1o*y1o*alpha/m1))*dt*dt*dt/6; 

    dy(n+1)=y2n;
    y(n+1)=y1n;
%    
    y1o= y(n+1);
    y2o= dy(n+1);
end
%
Y1(MC,:) = y;
Y2(MC,:) = dy;
% 
end
% 
u = mean(Y1);
udot = mean(Y2);
% 
figure(1),
subplot(2,4,i); plot(u,udot); hold on;
xlabel('$E[X]$','Interpreter','latex'); ylabel('$E[\dot{X}]$','Interpreter','latex');
% 
end
% 