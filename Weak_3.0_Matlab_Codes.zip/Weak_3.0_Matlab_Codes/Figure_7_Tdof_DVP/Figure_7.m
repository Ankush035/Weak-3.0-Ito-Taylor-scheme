% Fig 7: Displacement of the 2�DOF Duffing Van der pol system using order
% 3.0 weak Taylor and Milstein scheme
% 
%         Two dof Duffing-Van der pol oscillator under sine+WGN
% 
%   Higher order scheme (Weak Taylor 3.0 scheme) by Ito-Taylor eYpansion 
%  Comparison with Milstein scheme
% 
% Author: Tapas Tripura, Ankush Gogoi, Budhaditya Hazra
% Indian Institute of Technology Guwahati, Assam, India
% 
% ***********************************************************************
% 
clc
clear 
close all
% 
Nsim = 50; % No. of simulation,
% 
% System parameter :
k1=20; k2=5000; alpha=100;      
m1= 20; m2=10;
sig1=0.1; sig2=0.2; sig3=0.005;
c1=1; c2=2;
%
% Degradation parameter :
alpha1=0.55; alpha2=0.45; alpha3=0.3; alpha4=2; gamma=5*10^-5; beta=3;
%
% Time parameter:
T = 60;
dt=0.01;
time=0:dt:T;
% 
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Weak order 3.0 Ito-Taylor scheme
%                            dt = 0.01
% -----------------------------------------------------------------------
% 
for MC=1:Nsim
    MC       % MC run counter
%     
    Signal = 10*sin(2*pi*20*time);
%     
% Initialization of variables for states and degradation :
    y=zeros(5,numel(time));
    y(1,1)=0.001;
    Nd=zeros(1,numel(time));
    Nd(1)=1;
% Matrix for Multiple stochastic integrals-(DW,DZ,DWDZ_DT) :
% a three point random variable MSI,
    deltamat = [sqrt(dt)    0   0;  % dW
                   0    dt^1.5/2    dt^1.5/(2*sqrt(3));
                   0    dt^1.5/2   -dt^1.5/(2*sqrt(3))]; % dZ
% 
for j=1:numel(time)-1 %   Time integration
% 
    umat=randn(3,3);  % rows -> MSI's, && columns -> no. of floors..
    umat(:,3)=abs(umat(:,3)); % absolute random variable for degradation,
    delta = deltamat*umat;    % Initial MSI's..
%   
% Assignment of MSI's to its proper integrals::
    dW = delta(1,:);  % Brownian increament,
    Iws= delta(2,:);  % I5, Int(dBds),
    Isw= delta(3,:);  % I6, Int(dsdB),
    Iss= 0.5*dt^2; % Int(dsds),
    Iww= 0.5*(dW.^2-dt);   % Int(dBdB),
    Iwss= (1/6)*dt^2.*dW; I010=(1/6)*dt^2.*dW; I001=(1/6)*dt^2.*dW;  %Int(dBdsds),
    Iwww= (dW.^3)/6-(dW.*dt)/2; % Int(dBdBdB),
    Isww= (dW.^2-dt)*dt/6; I101=(dW.^2-dt)*dt/6; I110=(dW.^2-dt)*dt/6;  %Int(dsdBdB),
    Isss= dt^3/6;  % Int(dsdsds),
%     
% Drift terms for the 2DOF system :
    if j<=(35/dt)
        a1=y(2,j);
        a2=(1/m1)*(-c1*y(2,j)+y(1,j)*(k1-alpha*y(1,j)^2)-k2*(y(1,j)-y(3,j))-c2*(y(2,j)-y(4,j)));
        a3=y(4,j);
        a4=(1/m2)*(-c2*(y(4,j)-y(2,j))-k2*(y(3,j)-y(1,j)));
        a5= 0;
    else
        a1=y(2,j);
        a2=(1/m1)*(-c1*y(2,j)+y(1,j)*(k1-alpha*y(1,j)^2)-Nd(j)*k2*(y(1,j)-y(3,j))-c2*(y(2,j)-y(4,j)));
        a3=y(4,j);
        a4=(1/m2)*(-c2*(y(4,j)-y(2,j))-Nd(j)*k2*(y(3,j)-y(1,j)));
        a5=gamma*(y(3,j)^2+y(4,j)^2)^(beta/2);
    end
%     
% Power terms for the degradation model :
    T1 = (y(3,j)^2+y(4,j)^2)^(beta/2);
    T2 = (y(3,j)^2+y(4,j)^2)^((beta-2)/2);
    T3 = (y(3,j)^2+y(4,j)^2)^((beta-4)/2);
    T4 = (y(3,j)^2+y(4,j)^2)^((beta-6)/2);
%   
% Taylor weak 3.0 mapping for the 2DOF system :
    if j<=(35/dt)
      y(1,j+1) = y(1,j) + a1*dt + (sig1/m1)*y(1,j)*Iws(1) + a2*Iss...
                 +(a1*sig1/m1 + sig2*c2/(m1*m2) - sig1*(c1+c2)*y(1,j)/m1^2)*Iwss(1);
%   
      y(2,j+1) = y(2,j) + a2*dt + (sig1/m1)*y(1,j)*dW(1) + (sig2*c2/(m1*m2)-sig1*y(1,j)*(c1+c2)/m1^2)*Iws(1)...
                 + (a1/m1*(k1-3*alpha*y(1,j)^2-k2) - a2/m1*(c1+c2) + (a3/m1*k2) + (a4/m1*c2))*Iss...
                 + (a1*sig1/m1)*Isw(1) + (-sig1*(c1+c2)*a1/m1^2 + (1/m1)*(sig1*y(1,j)*k1/m1...
                 - 3*alpha*sig1*y(1,j)^3/m1 - k2*sig1*y(1,j)/m1) - (c1+c2)/m1*((c2*sig2/(m1*m2)-sig1*y(1,j)*(c1+c2)/m1^2))...
                 + k2*sig2/(m1*m2) + c2/m1*(sig1*y(1,j)*c2/(m1*m2) - sig2*c2/m2^2))*Iwss(1) + Signal(j)*dt;
%         
      y(3,j+1) = y(3,j) + a3*dt + sig2/m2*Iws(2) + a4*Iss + (sig1*y(1,j)*c2/(m1*m2)-sig2*c2/m2^2)*Iwss(2);
%   
      y(4,j+1) = y(4,j) + a4*dt + sig2/m2*dW(2) + (sig1*y(1,j)*c2/(m1*m2)-sig2*c2/m2^2)*Iws(2)...
                 + 1/m2*(a1*k2+a2*c2-a3*k2-a4*c2)*Iss + (sig1*a1*c2/(m1*m2)+ k2*sig1*y(1,j)/(m1*m2)...
                 + c2/(m2)*(sig2*c2/(m1*m2)-sig1*y(1,j)*(c1+c2)/m1^2) - k2*sig2/m2^2 - c2/m2^2*(sig1*y(1,j)*c2/m1-sig2*c2/m2))*Iwss(2);
%   
% Degradation state represented by 'y5',
      y(5,j+1) = y(5,j) + a5*dt + 0*dW(3);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %   
    else
      y(1,j+1) = y(1,j) + a1*dt + (sig1/m1)*y(1,j)*Iws(1) + a2*Iss...
                 +(a1*sig1/m1 + sig2*c2/(m1*m2) - sig1*(c1+c2)*y(1,j)/m1^2)*Iwss(1);
%   
      y(2,j+1) = y(2,j) + a2*dt + (sig1/m1)*y(1,j)*dW(1) + (sig2*c2/(m1*m2)-sig1*y(1,j)*(c1+c2)/m1^2)*Iws(1)...
                 + (a1/m1*(k1-3*alpha*y(1,j)^2-Nd(j)*k2)-a2/m1*(c1+c2)+(a3/m1*Nd(j)*k2)+(a4/m1*c2))*Iss...
                 + (a1*sig1/m1)*Isw(1) + (-sig1*(c1+c2)*a1/m1^2 + (1/m1)*(sig1*y(1,j)*k1/m1...
                 - 3*alpha*sig1*y(1,j)^3/m1 - Nd(j)*k2*sig1*y(1,j)/m1) - (c1+c2)/m1*(sig2*c2/(m1*m2)-sig1*y(1,j)*(c1+c2)/m1^2)...
                 + Nd(j)*k2*sig2/(m1*m2) + c2/m1*(sig1*y(1,j)*c2/(m1*m2)-sig2*c2/m2^2))*Iwss(1) + Signal(j)*dt;
%         
    y(3,j+1) = y(3,j) + a3*dt + sig2/m2*Iws(2) + a4*Iss + (sig1*y(1,j)*c2/(m1*m2)-sig2*c2/m2^2)*Iwss(2);
%   
    y(4,j+1) = y(4,j) + a4*dt + sig2/m2*dW(2) + (sig1*y(1,j)*c2/(m1*m2)-sig2*c2/m2^2)*Iws(2)...
             + 1/m2*(a1*Nd(j)*k2+a2*c2-a3*Nd(j)*k2-a4*c2)*Iss + (sig1*a1*c2/(m1*m2)+ Nd(j)*k2*sig1*y(1,j)/(m1*m2)...
             + c2/m2*(sig2*c2/(m1*m2)-sig1*y(1,j)*(c1+c2)/m1^2) - Nd(j)*k2*sig2/m2^2 - c2/m2*(sig1*y(1,j)*c2/(m1*m2)-sig2*c2/m2^2))*Iwss(2);
%   
% Degradation state represented by 'y5',
      y(5,j+1) = y(5,j) + a5*dt + sig3*dW(3) + gamma*sig2*beta*y(4,j)/m2*T2*Iws(3) +...
                (a3*gamma*T2*beta*y(3,j) + a4*gamma*beta*y(4,j)*T2 + 0.5*(sig2/m2)^2*gamma*beta*(T2+(beta-2)*y(4,j)^2*T3))*Iss...
                + (gamma*sig2*beta/m2*(a3*y(3,j)*y(4,j)*(beta-2)*T3 + a4*(T2+(beta-2)*y(4,j)^2*T3)...
                + 0.5*(sig2/m2)^2*((beta-2)*y(4,j)*T3 + 2*(beta-2)*y(4,j)*T3 + (beta-2)*(beta-4)*y(4,j)^3*T4))...
                + sig2*gamma*beta/m2*y(3,j)*(T2 + (beta-2)*y(4,j)^2*T3) - gamma*beta/m2*(c2*sig2/m2*(2*y(4,j)*T2+(beta-2)*y(4,j)^3*T3)...
                - c2*(sig1*y(1,j)*y(4,j)*T2/m1 + y(2,j)*sig2/m2*(T2+(beta-2)*y(4,j)^2*T3)) + Nd(j)*sig2/m2*k2*(y(3,j)-y(1,j))*(T2+(beta-2)*y(4,j)^2*T3))...
                + 0.5*(sig2/m2)^3*gamma*beta*((beta-2)*2*y(4,j)*T3 + (beta-2)*y(4,j)*T3 + (beta-4)*(beta-2)*y(4,j)^3*T4))*Iwss(3)...
                + (sig2/m2)^2*gamma*beta*(T2+(beta-2)*T3*y(4,j)^2)*Isww(3);
    end
%   
% Evolution of exponential decay,
    if j<=(35/dt)
        Nd(j+1) = 1;
    else
        Nd(j+1) = alpha1 + alpha2.*exp(-alpha3.*y(5,j).^alpha4);
    end
%     
end
% Storage of variables,
Y1(MC,:) = y(1,:);
Y2(MC,:) = y(2,:);
Y3(MC,:) = y(3,:);
Y4(MC,:) = y(4,:);
Y5(MC,:) = y(5,:);
DT(MC,:)= Nd;        % degradation function,
% 
end
MSC=toc;
% Sample solution of the Monte Carlo prediction :
u(1,:)= mean(Y1);   u(2,:)= mean(Y3);
udot(1,:)= mean(Y2);    udot(2,:)= mean(Y4);
uddot(1,:)= diff(udot(1,:));    uddot(2,:)= diff(udot(2,:));
Dt= mean(Y5);
figure,plot(mean(DT))
% 
% Plotting commands ::
% ------------------------------------------------------------------------
figure(1); 
subplot(2,1,1),plot(time,u(1,:),'--k'); hold on; xlabel('Time (s)'); ylabel('E[Y]^{u1}'); 
subplot(2,1,2),plot(time,u(2,:),'--k'); hold on; xlabel('Time (s)'); ylabel('E[Y]^{u2}'); 
% 
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Strong order 1.0 Milstein scheme
%                            dt = 0.0005
% -----------------------------------------------------------------------
% 
clear y u udot Y1 Y2 Y3 Y4 Y5 DT
% Time parameter:
dt=0.0005;    % Stable solution
time=0:dt:T;
% 
% Monte Carlo Simulation :
for MC=1:Nsim
    MC       % sample counter
%  
    Signal = 10*sin(2*pi*20*time);
%     
% Initialization of variables for states and degradation :
    y=zeros(5,numel(time));
    Nd=zeros(1,numel(time));
    Nd(1)=1;
% Matrix for Multiple stochastic integrals-(DW,DZ,DWDZ_DT) :
% a three point random variable MSI,
    deltamat = [sqrt(dt)    0   0;  % dW
                   0    dt^1.5/2    dt^1.5/(2*sqrt(3));
                   0    dt^1.5/2   -dt^1.5/(2*sqrt(3))]; % dZ
% 
for j=1:numel(time)-1 %   Time integration
% 
  umat=randn(3,3);  % rows -> MSI's, && columns -> no. of floors..
  umat(:,3)=abs(umat(:,3)); % absolute random variable for degradation,
  delta = deltamat*umat;    % Initial MSI's..
%   
% Assignment of MSI's to its proper integrals::
  dW = delta(1,:);  % Brownian increament,
%     
% Drift terms for the 2DOF system :
if j<=(35/dt)
    a1=y(2,j);
    a2=(1/m1)*(-c1*y(2,j)+y(1,j)*(k1-alpha*y(1,j)^2)-k2*(y(1,j)-y(3,j))-c2*(y(2,j)-y(4,j)));
    a3=y(4,j);
    a4=(1/m2)*(-c2*(y(4,j)-y(2,j))-k2*(y(3,j)-y(1,j)));
    a5= 0;
else
    a1=y(2,j);
    a2=(1/m1)*(-c1*y(2,j)+y(1,j)*(k1-alpha*y(1,j)^2)-Nd(j)*k2*(y(1,j)-y(3,j))-c2*(y(2,j)-y(4,j)));
    a3=y(4,j);
    a4=(1/m2)*(-c2*(y(4,j)-y(2,j))-Nd(j)*k2*(y(3,j)-y(1,j)));
    a5=gamma*(y(3,j)^2+y(4,j)^2)^(beta/2);
end

%     
% Power terms for the degradation model :
  T1 = (y(3,j)^2+y(4,j)^2)^(beta/2);
  T2 = (y(3,j)^2+y(4,j)^2)^((beta-2)/2);
  T3 = (y(3,j)^2+y(4,j)^2)^((beta-4)/2);
  T4 = (y(3,j)^2+y(4,j)^2)^((beta-6)/2);
%   
% Taylor weak 3.0 mapping for the 2DOF system :
  y(1,j+1) = y(1,j) + a1*dt;
%   
  y(2,j+1) = y(2,j) + a2*dt + (sig1/m1)*y(1,j)*dW(1) + Signal(j)*dt;
%         
  y(3,j+1) = y(3,j) + a3*dt;
%   
  y(4,j+1) = y(4,j) + a4*dt + sig2/m2*dW(2);
%   
% Degradation state represented by 'y5',
  y(5,j+1) = y(5,j) + a5*dt + 0*dW(3);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %   
%   
% Evolution of exponential decay,
    if j<=(35/dt)
        Nd(j+1) = 1;
    else
        Nd(j+1) = alpha1 + alpha2.*exp(-alpha3.*y(5,j).^alpha4);
    end
%     
end
% Storage of variables,
Y1(MC,:) = y(1,:);
Y2(MC,:) = y(2,:);
Y3(MC,:) = y(3,:);
Y4(MC,:) = y(4,:);
Y5(MC,:) = y(5,:);
DT(MC,:)= Nd;        % degradation function,
% 
end
MSC=toc;
% Sample solution of the Monte Carlo prediction :
u(1,:)= mean(Y1);   u(2,:)= mean(Y3);
udot(1,:)= mean(Y2);    udot(2,:)= mean(Y4);
Dt= mean(Y5);
% 
% Plotting commands ::
% ------------------------------------------------------------------------
figure(1); 
subplot(2,1,1),plot(time,u(1,:),'r'); hold on; 
subplot(2,1,2),plot(time,u(2,:),'r'); hold on;
% 
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%                   Strong order 1.0 Milstein scheme
%                            dt = 0.00091
% ------------------------------------------------------------------------
% 
clear y u udot Y1 Y2 Y3 Y4 Y5 DT
% 
% Time parameter:
dt=0.00091;    % Stable solution
time=0:dt:T;
% 
for MC=1:Nsim
    MC       % sample counter
%  
    Signal = 10*sin(2*pi*20*time);
%     
% Initialization of variables for states and degradation :
    y=zeros(5,numel(time));
    Nd=zeros(1,numel(time));
    Nd(1)=1;
% Matrix for Multiple stochastic integrals-(DW,DZ,DWDZ_DT) :
% a three point random variable MSI,
    deltamat = [sqrt(dt)    0   0;  % dW
                   0    dt^1.5/2    dt^1.5/(2*sqrt(3));
                   0    dt^1.5/2   -dt^1.5/(2*sqrt(3))]; % dZ
% 
for j=1:numel(time)-1 %   Time integration
% 
  umat=randn(3,3);  % rows -> MSI's, && columns -> no. of floors..
  umat(:,3)=abs(umat(:,3)); % absolute random variable for degradation,
  delta = deltamat*umat;    % Initial MSI's..
%   
% Assignment of MSI's to its proper integrals::
  dW = delta(1,:);  % Brownian increament,
%     
% Drift terms for the 2DOF system :
if j<=(35/dt)
    a1=y(2,j);
    a2=(1/m1)*(-c1*y(2,j)+y(1,j)*(k1-alpha*y(1,j)^2)-k2*(y(1,j)-y(3,j))-c2*(y(2,j)-y(4,j)));
    a3=y(4,j);
    a4=(1/m2)*(-c2*(y(4,j)-y(2,j))-k2*(y(3,j)-y(1,j)));
    a5= 0;
else
    a1=y(2,j);
    a2=(1/m1)*(-c1*y(2,j)+y(1,j)*(k1-alpha*y(1,j)^2)-Nd(j)*k2*(y(1,j)-y(3,j))-c2*(y(2,j)-y(4,j)));
    a3=y(4,j);
    a4=(1/m2)*(-c2*(y(4,j)-y(2,j))-Nd(j)*k2*(y(3,j)-y(1,j)));
    a5=gamma*(y(3,j)^2+y(4,j)^2)^(beta/2);
end
%     
% Power terms for the degradation model :
  T1 = (y(3,j)^2+y(4,j)^2)^(beta/2);
  T2 = (y(3,j)^2+y(4,j)^2)^((beta-2)/2);
  T3 = (y(3,j)^2+y(4,j)^2)^((beta-4)/2);
  T4 = (y(3,j)^2+y(4,j)^2)^((beta-6)/2);
%   
% Taylor weak 3.0 mapping for the 2DOF system :
  y(1,j+1) = y(1,j) + a1*dt;
%   
  y(2,j+1) = y(2,j) + a2*dt + (sig1/m1)*y(1,j)*dW(1) + Signal(j)*dt;
%         
  y(3,j+1) = y(3,j) + a3*dt;
%   
  y(4,j+1) = y(4,j) + a4*dt + sig2/m2*dW(2);
%   
% Degradation state represented by 'y5',
  y(5,j+1) = y(5,j) + a5*dt + 0*dW(3);
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %   
%   
% Evolution of exponential decay,
    if j<=(35/dt)
        Nd(j+1) = 1;
    else
        Nd(j+1) = alpha1 + alpha2.*exp(-alpha3.*y(5,j).^alpha4);
    end
%     
end
% Storage of variables,
Y1(MC,:) = y(1,:);
Y2(MC,:) = y(2,:);
Y3(MC,:) = y(3,:);
Y4(MC,:) = y(4,:);
Y5(MC,:) = y(5,:);
DT(MC,:)= Nd;        % degradation function,
% 
end
MSC=toc;
% Sample solution of the Monte Carlo prediction :
u(1,:)= mean(Y1);   u(2,:)= mean(Y3);
udot(1,:)= mean(Y2);    udot(2,:)= mean(Y4);
Dt= mean(Y5);
% 
% Plotting commands ::
% ------------------------------------------------------------------------
figure(1); 
subplot(2,1,1),plot(time,u(1,:),':g'); 
legend('Milstein, \Delta t =0.0005','Milstein, \Delta t =0.00091', ...
    'Weak 3.0, \Delta t =0.01','location','southwest');
subplot(2,1,2),plot(time,u(2,:),':g'); 
% 
% ++++++++++++++++++++++++++++++++ END +++++++++++++++++++++++++++++++++++
% 