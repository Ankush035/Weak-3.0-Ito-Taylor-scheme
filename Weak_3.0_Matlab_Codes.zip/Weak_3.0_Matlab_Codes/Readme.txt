The code is a part of the manuscript titled:
```````````````````````````````````````````````````````````````````````````
An Ito-Taylor weak 3.0 method for Stochastic Dynamics of Nonlinear systems

```````````````````````````````````````````````````````````````````````````

Journal: Applied Mathematical Modelling, Elsevier.

Authors: Tapas Tripura, Ankush Gogoi, Budhaditya Hazra

Note:
i. For clear understanding about the codes please refer the theory present in the paper.
ii. For any further query contact the authors.
(The contact address is present in the paper).


Copyright: The codes are subjected to use provided due citation is given to the paper appropriately.